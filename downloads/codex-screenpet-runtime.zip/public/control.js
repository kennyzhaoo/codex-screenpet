(function () {
  var selectedState = "working";
  var AUTH_STORAGE_KEY = "codexMobilePetPin";
  var authPin = storageGet(AUTH_STORAGE_KEY);

  function $(id) {
    return document.getElementById(id);
  }

  function xhr(method, path, body, done) {
    var request = new XMLHttpRequest();
    request.open(method, path, true);
    if (authPin) {
      request.setRequestHeader("X-Codex-Pet-Pin", authPin);
    }
    request.onreadystatechange = function () {
      if (request.readyState === 4) {
        if (request.status >= 200 && request.status < 300) {
          try {
            done(null, JSON.parse(request.responseText));
          } catch (err) {
            done(err);
          }
        } else {
          var error = new Error("HTTP " + request.status);
          error.status = request.status;
          done(error);
        }
      }
    };
    request.setRequestHeader("Content-Type", "application/json");
    request.send(JSON.stringify(body || {}));
  }

  function storageGet(key) {
    try {
      return window.localStorage ? String(window.localStorage.getItem(key) || "") : "";
    } catch (err) {
      return "";
    }
  }

  function storageSet(key, value) {
    try {
      if (window.localStorage) {
        window.localStorage.setItem(key, value);
      }
    } catch (err) {
    }
  }

  function requestPin(done) {
    var pin = window.prompt("Enter Blinky Codex ScreenPet PIN");
    if (!pin) {
      done(false);
      return;
    }
    authPin = String(pin);
    storageSet(AUTH_STORAGE_KEY, authPin);
    done(true);
  }

  function setState(state) {
    selectedState = state;
    var buttons = document.getElementsByTagName("button");
    var i;
    for (i = 0; i < buttons.length; i += 1) {
      if (buttons[i].getAttribute("data-state") === state) {
        buttons[i].className = "selected";
      } else if (buttons[i].getAttribute("data-state")) {
        buttons[i].className = "";
      }
    }
  }

  function updateCurrent(status) {
    if (status.tasks) {
      $("current").innerHTML = "Running: " + status.activeCount + " / Total: " + status.totalCount;
      return;
    }
    $("current").innerHTML = "Current: " + status.state + " - " + (status.task || "No task") + " - " + status.message + " (" + status.progress + "%)";
  }

  function load() {
    var request = new XMLHttpRequest();
    request.open("GET", "/api/tasks?ts=" + new Date().getTime(), true);
    if (authPin) {
      request.setRequestHeader("X-Codex-Pet-Pin", authPin);
    }
    request.onreadystatechange = function () {
      if (request.readyState === 4 && request.status === 200) {
        var board = JSON.parse(request.responseText);
        var status = board.status || {};
        var task = board.tasks && board.tasks.length ? board.tasks[0] : null;
        setState(status.state || "working");
        $("taskId").value = task ? task.id : "current";
        $("task").value = task ? task.title : status.task || "";
        $("title").value = status.title || "";
        $("message").value = status.message || "";
        $("detail").value = status.detail || "";
        $("progress").value = status.progress || 0;
        updateCurrent(board);
      } else if (request.readyState === 4 && request.status === 401) {
        requestPin(function (ok) {
          if (ok) {
            load();
          }
        });
      }
    };
    request.send();
  }

  function bind() {
    var buttons = $("buttons").getElementsByTagName("button");
    var i;
    for (i = 0; i < buttons.length; i += 1) {
      buttons[i].onclick = function () {
        setState(this.getAttribute("data-state"));
        return false;
      };
    }

    $("form").onsubmit = function () {
      var payload = {
        id: $("taskId").value,
        state: selectedState,
        title: $("task").value,
        petTitle: $("title").value,
        message: $("message").value,
        detail: $("detail").value,
        progress: $("progress").value
      };

      xhr("POST", "/api/tasks", payload, function (err, status) {
        if (err) {
          if (err.status === 401) {
            requestPin(function () {});
          }
          $("current").innerHTML = "Update failed";
          return;
        }
        updateCurrent(status);
      });

      return false;
    };
  }

  bind();
  setState(selectedState);
  load();
}());
