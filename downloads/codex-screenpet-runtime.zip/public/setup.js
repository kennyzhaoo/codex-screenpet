(function () {
  var latestAuth = null;
  var latestSetup = null;
  var latestErrorMessage = "";
  var setupErrorActive = false;
  var LANGUAGE_STORAGE_KEY = "setupLanguagePreference";
  var currentLang = chooseInitialLanguage();

  var I18N = {
    en: {
      documentTitle: "Blinky Setup Center",
      language: "Language",
      topBrandTitle: "Blinky Setup",
      topBrandSubtitle: "ScreenPet local console",
      navReadiness: "1. READINESS",
      navPassword: "2. PASSWORD",
      navRemote: "3. REMOTE",
      navDesktop: "4. PERMISSION",
      navNotes: "5. NOTES",
      eyebrow: "Console",
      heroVersionLabel: "VERSION",
      heroPinLabel: "Blinky password",
      heroPinCaption: "Unlock the phone dashboard.",
      summary: "Spare phone. Live Codex tasks. Local control.",
      statusTitle: "Status",
      statusSectionCopy: "Local checks before opening Blinky.",
      loading: "Loading...",
      pinTitle: "Blinky Password",
      pinReadoutLabel: "PHONE LOGIN KEY",
      pinHintDefault: "This does not refresh. Enter it on the Blinky phone page.",
      pinPlaceholder: "Set 6-digit PIN",
      pinEditHintDefault: "Use exactly 6 digits. Saving updates the phone login immediately.",
      firstRunTitle: "FIRST RUN FLOW",
      firstRunStepsLabel: "3 STEPS",
      firstRunOpenTitle: "Open an address below",
      firstRunOpenText: "Use same Wi-Fi, private network, or a trusted tunnel.",
      firstRunPasswordTitle: "Enter Blinky Password",
      firstRunPasswordText: "The password is shown only on this Mac setup page.",
      firstRunTaskTitle: "Pick a Codex task",
      firstRunTaskText: "Read tasks and send log-confirmed instructions.",
      urlsTitle: "Remote Access",
      manualTunnelTitle: "Custom tunnel URL",
      manualTunnelDescription: "Save a trusted tunnel URL when same Wi-Fi is not available.",
      tunnelHintDefault: "Clear and save to hide the saved tunnel URL.",
      permissionTitle: "<span>Blinky Accessibility</span><span>Optional</span>",
      permissionSectionCopy: "Optional enhancement, not the switch for the whole app.",
      permissionCheck: "CHECK",
      permissionCheckingTitle: "Checking Accessibility authorization...",
      permissionCheckingDetail: "Optional. Reading still works; visible Desktop UI delivery needs Mac authorization.",
      openPermissionSettings: "Open Permission Settings",
      permissionNote: "This is optional. Without it, the phone page can still log in, read task logs, and confirm sends against the target task log. Accessibility only lets Blinky try delivery through the visible Codex Desktop window; file or folder access prompts still need separate approval on this Mac.",
      permissionBulletReading: "Reading local Codex task logs works without it.",
      permissionBulletSending: "Send success means the target task log recorded the instruction.",
      permissionBulletPrompts: "Folder and Accessibility prompts must be approved on this Mac.",
      detailsTitle: "Notes & Limits",
      detailsSectionCopy: "Availability, delivery display, and permission boundaries.",
      detailsAvailabilityTitle: "Menu Bar Basics",
      detailsAvailabilityIntro: "The Blinky menu keeps everyday controls.",
      detailsLimitPower: "Open Setup shows the QR code and Blinky password.",
      detailsLimitLid: "Launch at Login opens Blinky with macOS; Start Server turns on the phone dashboard.",
      detailsLimitApp: "Stop Server turns off the local dashboard server.",
      detailsSyncTitle: "Delivery Display Boundary",
      detailsSyncIntro: "The phone follows Codex task logs on this Mac. Visible-window updates depend on the delivery channel.",
      detailsSyncLog: "Task updates come from local Codex logs.",
      detailsSyncConfirm: "Send success means the target task log recorded it; first send may need one Mac approval.",
      detailsSyncMirror: "Desktop UI delivery should appear in the visible Codex Desktop window; Codex RPC, Desktop follower, or Queued may only be log-confirmed.",
      detailsSyncSource: "Use the delivery label and phone task log as the source of truth.",
      detailsMotionTitle: "Blinky Animation",
      detailsMotionIntro: "Blinky respects the phone or browser motion settings.",
      detailsMotionSetting: "On iPhone or iPad, check Settings > Accessibility > Motion > Reduce Motion.",
      detailsMotionData: "Reduce Motion can stop blinking or bobbing, but task polling and sending still work.",
      detailsMotionPower: "Low Power Mode or very old browsers can also make animation more conservative.",
      detailsTrustTitle: "Privacy & Device Safety",
      detailsTrustIntro: "Blinky is local-first and does not add its own cloud sync.",
      detailsTrustLocal: "Tasks, Blinky password, and settings stay on this Mac.",
      detailsTrustGate: "Phone access requires the Blinky Password; setup opens only on this Mac.",
      detailsTrustTunnel: "Use trusted Wi-Fi, Tailscale, or a tunnel you control. Do not publish tunnel URLs.",
      detailsTrustFirstSend: "First real send: approve any macOS or Codex prompt asking Codex or Blinky to access a project folder.",
      detailsTrustPermission: "macOS permissions are opt-in; Blinky cannot silently grant folder or Accessibility access.",
      footerSlogan: "Stop waiting on AI,\nlet Blinky keep watch.",
      footerCreditLabel: "BLINKY by",
      footerSignature: "Kenny Zhao",
      save: "Save",
      saving: "Saving...",
      copy: "Copy",
      copied: "Copied",
      modeDemo: "Demo data · v{version}",
      modeLive: "Blinky Codex ScreenPet · v{version}",
      pinDisabled: "Blinky password is disabled for this run.",
      pinHidden: "Hidden",
      pinHiddenHint: "Open this setup page on the Mac itself to see the Blinky password.",
      pinStable: "Stable {kind}. It only changes when you save a new one here.",
      pinKindCustom: "custom password",
      pinKindLocal: "local PIN",
      pinProtectionDisabled: "PIN protection is disabled for this run.",
      pinEnvDisabled: "PET_AUTH_PIN is set in the environment.",
      pinConfiguredElsewhere: "This password is configured outside the setup page.",
      pinSaveHint: "Use exactly 6 digits. Saving updates the phone login immediately.",
      pinTooShort: "Use exactly 6 digits.",
      pinCouldNotSave: "Could not save Blinky password.",
      pinSaved: "Saved. Use this password the next time the phone asks.",
      tunnelCouldNotSave: "Could not save tunnel URL.",
      tunnelSaved: "Saved. Use this URL from the phone when the tunnel is running.",
      tunnelCleared: "Tunnel URL cleared.",
      urlGroupDetected: "Detected phone addresses",
      urlPhone: "Phone",
      urlGroupSavedTunnel: "Saved tunnel",
      urlTunnel: "Tunnel URL",
      urlLocalNetwork: "Local network",
      urlWifiLocalNetwork: "Wi-Fi local network",
      urlEthernetLocalNetwork: "Wired local network",
      emptyUrls: "No URLs found yet.",
      betaLabel: "Beta",
      qrTitle: "Scan to open on phone",
      qrTitleFor: "{label}",
      qrTarget: "{label}",
      qrCopyUrl: "Copy URL",
      qrPrivateTitle: "Private network",
      qrPrivatePlaceholderStatus: "No private network address detected.",
      qrPrivatePlaceholderStep: "Detected Tailscale, ZeroTier, or NetBird addresses will appear here automatically.",
      qrNoUrlTitle: "QR code will appear when a phone URL is ready",
      qrNoUrlDetail: "Connect this Mac to Wi-Fi, use Tailscale beta, or save a trusted tunnel URL.",
      qrDetectedNote: "Detected networks appear above automatically.",
      qrTooLongTitle: "This URL is too long for the built-in QR code",
      qrTooLongDetail: "Use Copy URL and paste it into the phone browser instead.",
      qrLocalStep: "Same local network: use this address.",
      qrWifiLocalStep: "Phone on the same Wi-Fi: use this address.",
      qrEthernetLocalStep: "Wired Mac network: use this from the same router's Wi-Fi.",
      qrTailscaleStep: "Away from Wi-Fi: use Tailscale.",
      qrTunnelStep: "Away from Wi-Fi: use this tunnel.",
      qrDefaultStep: "Open this on the phone.",
      remoteUseTitle: "Try the phone page now",
      remoteUseIntro: "Scan one QR code, then enter the Blinky Password.",
      remoteUseLocal: "Same Wi-Fi: use Local network.",
      remoteUsePrivate: "Away from Wi-Fi: use Tailscale or a tunnel.",
      fullscreenGuideTitle: "How to get the best Blinky experience?",
      fullscreenGuideSummary: "Add Blinky to your phone Home Screen for the cleanest full-screen view.",
      fullscreenGuideAppleTitle: "iPhone / iPad",
      fullscreenGuideAppleText: "Safari: Share > Add to Home Screen. Open Blinky from the Home Screen icon.",
      fullscreenGuideChromeTitle: "Android Chrome",
      fullscreenGuideChromeText: "Chrome: menu > Add to Home screen or Install app.",
      fullscreenGuideSamsungTitle: "Samsung Internet",
      fullscreenGuideSamsungText: "Menu: Add page to > Home screen or Apps screen, when available.",
      fullscreenGuideOtherTitle: "Xiaomi / Other Android",
      fullscreenGuideOtherText: "Look for Add shortcut, Add to Home screen, Install app, or Full screen. If missing, use Chrome.",
      remoteDetailsTitle: "What these addresses mean",
      tipSameWifi: "Same Wi-Fi",
      tipSameWifiReady: "Best first try.",
      tipSameWifiMissing: "Connect this Mac to Wi-Fi.",
      tipPrivateVpn: "Private network",
      tipPrivateVpnReady: "For away-from-home use. Beta.",
      tipPrivateVpnMissing: "Tailscale / ZeroTier / NetBird. Beta.",
      tipManualTunnel: "Custom tunnel URL",
      tipManualTunnelText: "Paste your tunnel link here.",
      securityNote: "Use a strong Blinky password for tunnels.",
      badgeOk: "OK",
      badgeWarn: "WARN",
      permissionOkBadge: "AUTH",
      permissionAllowBadge: "NEEDS AUTH",
      permissionReadyTitle: "Blinky Accessibility authorized",
      permissionAllowTitle: "Authorize Accessibility for Blinky",
      permissionDetailAllowed: "Blinky Accessibility is authorized.",
      permissionDetailDefaultWarn: "Optional. Reading works; authorize this Mac before using visible Desktop UI delivery.",
      permissionDetailServerAllowed: "allowed for visible Desktop UI delivery",
      permissionDetailServerAllow: "To deliver phone instructions through the visible Codex Desktop window, allow Blinky Codex ScreenPet.app in Accessibility. First file or folder prompts may still need one Mac approval.",
      permissionDetailMacosOnly: "macOS only",
      checkDefault: "Check",
      checksEmpty: "No checks available.",
      checkNodeLabel: "Node.js",
      checkCodexAppLabel: "Codex Desktop app",
      checkCodexStateLabel: "Codex state database",
      checkCodexLogsLabel: "Codex logs database",
      checkNetworkLabel: "Phone network address",
      checkRemoteControlLabel: "Desktop UI permission",
      checkRemoteControlReady: "authorized",
      checkRemoteControlOptional: "optional. Enable below.",
      checkInstalled: "installed",
      checkNotFoundApplications: "not found in /Applications",
      checkAvailable: "available",
      checkDetected: "Detected",
      checkNotFound: "not found",
      checkNoPrivateAddress: "no private network address found",
      setupUnavailable: "Setup unavailable",
      setupLocalOnlyHint: "Open setup on this Mac: http://127.0.0.1:8788/setup",
      setupLabel: "Setup"
    },
    zh: {
      documentTitle: "Blinky Setup Center",
      language: "语言",
      topBrandTitle: "Blinky Setup",
      topBrandSubtitle: "ScreenPet 本机控制台",
      navReadiness: "1. 准备",
      navPassword: "2. 密码",
      navRemote: "3. 远程",
      navDesktop: "4. 授权",
      navNotes: "5. 说明",
      eyebrow: "控制台",
      heroVersionLabel: "版本",
      heroPinLabel: "Blinky 密码",
      heroPinCaption: "用于解锁手机看板。",
      summary: "把手机、平板或任意浏览器设备变成 Codex Desktop 任务小看板。",
      statusTitle: "状态",
      statusSectionCopy: "本机环境检查、手机网络地址和 Desktop UI 权限状态。",
      loading: "加载中...",
      pinTitle: "Blinky 密码",
      pinReadoutLabel: "手机登录密码",
      pinHintDefault: "这个密码不会自动刷新。请在 Blinky 手机页面输入它。",
      pinPlaceholder: "设置 6 位数字密码",
      pinEditHintDefault: "仅限 6 位数字。保存后会立即更新手机登录密码。",
      firstRunTitle: "首次使用流程",
      firstRunStepsLabel: "3 步",
      firstRunOpenTitle: "打开下方网址",
      firstRunOpenText: "同 Wi-Fi、私有网络或可信 tunnel 都可以。",
      firstRunPasswordTitle: "输入 Blinky 密码",
      firstRunPasswordText: "密码只在这台 Mac 的 setup 页面显示。",
      firstRunTaskTitle: "选择 Codex 任务",
      firstRunTaskText: "从手机看任务，并发送已确认送达的指令。",
      urlsTitle: "远程访问",
      manualTunnelTitle: "自定义内网穿透 URL",
      manualTunnelDescription: "如果同 Wi-Fi 不方便，可在这里保存可信 tunnel URL。",
      tunnelHintDefault: "清空并保存后会隐藏已保存的 tunnel URL。",
      permissionTitle: "<span>Blinky 辅助功能</span><span>可选</span>",
      permissionSectionCopy: "这是可选增强项，不是整个 App 的总开关。",
      permissionCheck: "检查",
      permissionCheckingTitle: "正在检查辅助功能授权...",
      permissionCheckingDetail: "可选。不开启也能查看；可见窗口投递需要 Mac 授权。",
      openPermissionSettings: "打开权限设置",
      permissionNote: "这是可选增强项。不开启也能登录手机页、读取任务日志，并通过目标任务日志确认发送结果。开启后，Blinky 才能尝试把指令投递到可见的 Codex Desktop 窗口；文件夹访问弹窗仍需你在 Mac 上单独允许。",
      permissionBulletReading: "不开启也能读取本机 Codex 任务日志。",
      permissionBulletSending: "发送成功代表目标任务日志已记录这条指令。",
      permissionBulletPrompts: "文件夹和辅助功能权限都必须在 Mac 上手动允许。",
      detailsTitle: "补充说明",
      detailsSectionCopy: "菜单栏基础操作、投递显示边界、Blinky 动画和隐私安全。",
      detailsAvailabilityTitle: "菜单栏基础操作",
      detailsAvailabilityIntro: "Blinky 菜单栏保留日常操作。",
      detailsLimitPower: "Open Setup 显示二维码和 Blinky 密码。",
      detailsLimitLid: "Launch at Login 随 macOS 打开；Start Server 开启手机看板。",
      detailsLimitApp: "Stop Server 关闭本机 dashboard 服务。",
      detailsSyncTitle: "投递显示边界",
      detailsSyncIntro: "手机页跟随这台 Mac 的 Codex 任务日志；Mac 可见窗口是否更新取决于投递通道。",
      detailsSyncLog: "任务更新来自本地 Codex 日志。",
      detailsSyncConfirm: "发送成功代表目标任务日志已记录这条指令；首次发送可能需要在 Mac 上允许一次。",
      detailsSyncMirror: "Desktop UI 投递通常会出现在可见的 Codex Desktop 窗口；Codex RPC、Desktop follower 或 Queued 可能只完成日志确认。",
      detailsSyncSource: "以投递标签和手机任务日志为准。",
      detailsMotionTitle: "Blinky 动画",
      detailsMotionIntro: "Blinky 会尊重手机或浏览器的动态效果设置。",
      detailsMotionSetting: "iPhone / iPad 路径：设置 > 辅助功能 > 动态效果 > 减少动态效果。",
      detailsMotionData: "开启“减少动态效果”可能停止眨眼或浮动，但任务轮询和发送指令不受影响。",
      detailsMotionPower: "低电量模式或很旧的浏览器也可能让动画表现更保守。",
      detailsTrustTitle: "隐私与设备安全",
      detailsTrustIntro: "Blinky 按本地优先方式设计，不内置云同步。",
      detailsTrustLocal: "任务、Blinky 密码和设置数据保存在这台 Mac。",
      detailsTrustGate: "手机访问需要 Blinky 密码；setup 页面只允许 Mac 本机打开。",
      detailsTrustTunnel: "只使用可信 Wi-Fi、Tailscale 或你掌控的 tunnel。不要公开 tunnel URL。",
      detailsTrustFirstSend: "第一次真实发送：如果 Mac 询问 Codex 或 Blinky 是否允许访问项目文件夹，请在 Mac 上允许一次。",
      detailsTrustPermission: "macOS 权限需要你手动允许；Blinky 不会静默获得文件夹或辅助功能访问。",
      footerSlogan: "等待AI的时间，\nBlinky还给你。",
      footerCreditLabel: "BLINKY by",
      footerSignature: "Kenny Zhao",
      save: "保存",
      saving: "保存中...",
      copy: "复制",
      copied: "已复制",
      modeDemo: "演示数据 · v{version}",
      modeLive: "Blinky Codex ScreenPet · v{version}",
      pinDisabled: "本次运行已关闭 Blinky 密码。",
      pinHidden: "已隐藏",
      pinHiddenHint: "请在 Mac 本机打开这个 setup 页面查看 Blinky 密码。",
      pinStable: "稳定的{kind}。只有你在这里保存新密码时才会变化。",
      pinKindCustom: "自定义密码",
      pinKindLocal: "本地 PIN",
      pinProtectionDisabled: "本次运行已关闭 PIN 保护。",
      pinEnvDisabled: "当前通过环境变量 PET_AUTH_PIN 设置密码。",
      pinConfiguredElsewhere: "这个密码由 setup 页面之外的配置控制。",
      pinSaveHint: "仅限 6 位数字。保存后会立即更新手机登录密码。",
      pinTooShort: "请输入 6 位数字。",
      pinCouldNotSave: "无法保存 Blinky 密码。",
      pinSaved: "已保存。下次手机要求输入密码时请使用它。",
      tunnelCouldNotSave: "无法保存 tunnel URL。",
      tunnelSaved: "已保存。隧道运行时，请在手机上打开这个 URL。",
      tunnelCleared: "已清空 tunnel URL。",
      urlGroupDetected: "检测到的手机访问地址",
      urlPhone: "手机",
      urlGroupSavedTunnel: "已保存的 tunnel",
      urlTunnel: "Tunnel URL",
      urlLocalNetwork: "本地网络",
      urlWifiLocalNetwork: "Wi-Fi 本地网络",
      urlEthernetLocalNetwork: "网线本地网络",
      emptyUrls: "暂时没有找到 URL。",
      betaLabel: "Beta",
      qrTitle: "扫码在手机上打开",
      qrTitleFor: "{label}",
      qrTarget: "{label}",
      qrCopyUrl: "复制 URL",
      qrPrivateTitle: "私有网络",
      qrPrivatePlaceholderStatus: "暂未检测到私有网络地址。",
      qrPrivatePlaceholderStep: "检测到 Tailscale / ZeroTier / NetBird 后会自动显示在这里。",
      qrNoUrlTitle: "检测到手机可用地址后会显示二维码",
      qrNoUrlDetail: "请让这台 Mac 连接 Wi-Fi、使用 Tailscale Beta，或保存一个可信 tunnel URL。",
      qrDetectedNote: "检测到的网络会自动在上方显示。",
      qrTooLongTitle: "这个 URL 对内置二维码来说太长",
      qrTooLongDetail: "请用“复制 URL”，再粘贴到手机浏览器打开。",
      qrLocalStep: "同一局域网：用这个地址。",
      qrWifiLocalStep: "手机连同一 Wi-Fi：用这个地址。",
      qrEthernetLocalStep: "Mac 接网线：手机连同一路由器 Wi-Fi 时用这个地址。",
      qrTailscaleStep: "不在同 Wi-Fi：用 Tailscale。",
      qrTunnelStep: "不在同 Wi-Fi：用这个 tunnel。",
      qrDefaultStep: "手机打开这个地址。",
      remoteUseTitle: "现在可以这样试",
      remoteUseIntro: "扫一个二维码，然后输入 Blinky 密码。",
      remoteUseLocal: "同 Wi-Fi：用本地网络。",
      remoteUsePrivate: "不在同 Wi-Fi：用 Tailscale 或 tunnel。",
      fullscreenGuideTitle: "如何获得最佳Blinky体验？",
      fullscreenGuideSummary: "把 Blinky 添加到手机主屏幕，打开后更像全屏 App。",
      fullscreenGuideAppleTitle: "iPhone / iPad",
      fullscreenGuideAppleText: "Safari：点分享按钮 > 添加到主屏幕，再从桌面图标打开。",
      fullscreenGuideChromeTitle: "Android Chrome",
      fullscreenGuideChromeText: "Chrome：右上角菜单 > 添加到主屏幕 / 安装应用。",
      fullscreenGuideSamsungTitle: "Samsung Internet",
      fullscreenGuideSamsungText: "菜单里找 Add page to、Home screen 或 Apps screen。",
      fullscreenGuideOtherTitle: "小米 / 其他安卓浏览器",
      fullscreenGuideOtherText: "找“添加到桌面 / 添加快捷方式 / 安装应用 / 全屏”。找不到就用 Chrome。",
      remoteDetailsTitle: "这些地址有什么区别",
      tipSameWifi: "同一 Wi-Fi",
      tipSameWifiReady: "第一次优先用它。",
      tipSameWifiMissing: "让 Mac 连上 Wi-Fi。",
      tipPrivateVpn: "私有网络",
      tipPrivateVpnReady: "外出时用。Beta。",
      tipPrivateVpnMissing: "Tailscale / ZeroTier / NetBird。Beta。",
      tipManualTunnel: "内网穿透 URL",
      tipManualTunnelText: "把穿透链接贴这里。",
      securityNote: "Tunnel 场景请用强 Blinky 密码。",
      badgeOk: "正常",
      badgeWarn: "注意",
      permissionOkBadge: "已授权",
      permissionAllowBadge: "未授权",
      permissionReadyTitle: "Blinky 辅助功能已授权",
      permissionAllowTitle: "为Blinky授权辅助功能",
      permissionDetailAllowed: "Blinky 辅助功能已授权。",
      permissionDetailDefaultWarn: "可选。不开启仍可查看；需要可见窗口投递时，请先在 Mac 上授权。",
      permissionDetailServerAllowed: "已允许可见 Desktop UI 投递",
      permissionDetailServerAllow: "如需把手机指令投递到可见的 Codex Desktop 窗口，请在“辅助功能”里允许 Blinky Codex ScreenPet.app；首次文件夹弹窗仍可能需要在 Mac 上允许一次。",
      permissionDetailMacosOnly: "仅 macOS 支持",
      checkDefault: "检查项",
      checksEmpty: "暂无检查项。",
      checkNodeLabel: "Node.js",
      checkCodexAppLabel: "Codex Desktop App",
      checkCodexStateLabel: "Codex 状态数据库",
      checkCodexLogsLabel: "Codex 日志数据库",
      checkNetworkLabel: "手机网络地址",
      checkRemoteControlLabel: "Desktop UI 权限",
      checkRemoteControlReady: "已授权",
      checkRemoteControlOptional: "可选，可在下方开启。",
      checkInstalled: "已安装",
      checkNotFoundApplications: "未在 /Applications 中找到",
      checkAvailable: "可用",
      checkDetected: "已检测到",
      checkNotFound: "未找到",
      checkNoPrivateAddress: "未找到私有网络地址",
      setupUnavailable: "Setup 不可用",
      setupLocalOnlyHint: "请在这台 Mac 上打开 setup：http://127.0.0.1:8788/setup",
      setupLabel: "Setup"
    }
  };

  function $(id) {
    return document.getElementById(id);
  }

  function chooseInitialLanguage() {
    var storedLang = "";
    var browserLang = "";
    var browserLanguages = [];

    try {
      storedLang = localStorage.getItem(LANGUAGE_STORAGE_KEY) || "";
    } catch (err) {
    }

    if (storedLang === "zh" || storedLang === "en") {
      return storedLang;
    }

    try {
      if (navigator.languages && navigator.languages.length) {
        browserLanguages = navigator.languages;
      }
    } catch (err) {
    }

    browserLang = String(browserLanguages[0] || navigator.language || navigator.userLanguage || "").toLowerCase();
    return browserLang.indexOf("zh") === 0 ? "zh" : "en";
  }

  function tr(key, values) {
    var pack = I18N[currentLang] || I18N.en;
    var text = pack[key];
    var name;

    if (typeof text !== "string") {
      text = I18N.en[key];
    }

    if (typeof text !== "string") {
      text = key;
    }

    if (values) {
      for (name in values) {
        if (Object.prototype.hasOwnProperty.call(values, name)) {
          text = text.replace(new RegExp("\\{" + name + "\\}", "g"), String(values[name]));
        }
      }
    }

    return text;
  }

  function hasText(key) {
    return typeof (I18N[currentLang] || {})[key] === "string" || typeof I18N.en[key] === "string";
  }

  function setText(id, key) {
    var element = $(id);
    if (element) {
      element.innerHTML = escapeHtml(tr(key));
    }
  }

  function setHtml(id, key) {
    var element = $(id);
    if (element) {
      element.innerHTML = tr(key);
    }
  }

  function setPlaceholder(id, key) {
    var element = $(id);
    if (element) {
      element.setAttribute("placeholder", tr(key));
    }
  }

  function refreshSetupFavicon() {
    var head = document.getElementsByTagName ? document.getElementsByTagName("head")[0] : null;
    var links;
    var iconHref;
    var icon;
    var shortcut;
    var i;
    var rel;

    if (!head || !document.createElement) {
      return;
    }

    links = head.getElementsByTagName ? head.getElementsByTagName("link") : [];
    for (i = links.length - 1; i >= 0; i -= 1) {
      rel = (links[i].getAttribute("rel") || "").toLowerCase();
      if ((rel === "icon" || rel === "shortcut icon") && links[i].parentNode) {
        links[i].parentNode.removeChild(links[i]);
      }
    }

    iconHref = "/blinky-setup-favicon-20260527.png?runtime=" + String(new Date().getTime());

    icon = document.createElement("link");
    icon.setAttribute("rel", "icon");
    icon.setAttribute("type", "image/png");
    icon.setAttribute("sizes", "32x32");
    icon.setAttribute("href", iconHref);
    head.appendChild(icon);

    shortcut = document.createElement("link");
    shortcut.setAttribute("rel", "shortcut icon");
    shortcut.setAttribute("type", "image/png");
    shortcut.setAttribute("href", iconHref);
    head.appendChild(shortcut);
  }

  function applyLanguage() {
    if (document.documentElement) {
      document.documentElement.setAttribute("lang", currentLang === "zh" ? "zh-CN" : "en");
    }

    document.title = tr("documentTitle");
    if ($("languageSwitch")) {
      $("languageSwitch").setAttribute("aria-label", tr("language"));
    }

    setText("topBrandTitle", "topBrandTitle");
    setText("topBrandSubtitle", "topBrandSubtitle");
    setText("navReadiness", "navReadiness");
    setText("navPassword", "navPassword");
    setText("navRemote", "navRemote");
    setText("navDesktop", "navDesktop");
    setText("navNotes", "navNotes");
    setText("eyebrow", "eyebrow");
    setText("heroVersionLabel", "heroVersionLabel");
    setText("heroPinLabel", "heroPinLabel");
    setText("heroPinCaption", "heroPinCaption");
    setText("summary", "summary");
    setText("statusTitle", "statusTitle");
    setText("statusSectionCopy", "statusSectionCopy");
    setText("pinTitle", "pinTitle");
    setText("pinReadoutLabel", "pinReadoutLabel");
    setText("pinHint", "pinHintDefault");
    setPlaceholder("customPin", "pinPlaceholder");
    setText("savePin", "save");
    setText("pinEditHint", "pinEditHintDefault");
    setText("firstRunTitle", "firstRunTitle");
    setText("firstRunStepsLabel", "firstRunStepsLabel");
    setText("firstRunOpenTitle", "firstRunOpenTitle");
    setText("firstRunOpenText", "firstRunOpenText");
    setText("firstRunPasswordTitle", "firstRunPasswordTitle");
    setText("firstRunPasswordText", "firstRunPasswordText");
    setText("firstRunTaskTitle", "firstRunTaskTitle");
    setText("firstRunTaskText", "firstRunTaskText");
    setText("urlsTitle", "urlsTitle");
    setText("fullscreenGuideTitle", "fullscreenGuideTitle");
    setText("fullscreenGuideSummary", "fullscreenGuideSummary");
    setText("fullscreenGuideAppleTitle", "fullscreenGuideAppleTitle");
    setText("fullscreenGuideAppleText", "fullscreenGuideAppleText");
    setText("fullscreenGuideChromeTitle", "fullscreenGuideChromeTitle");
    setText("fullscreenGuideChromeText", "fullscreenGuideChromeText");
    setText("fullscreenGuideSamsungTitle", "fullscreenGuideSamsungTitle");
    setText("fullscreenGuideSamsungText", "fullscreenGuideSamsungText");
    setText("fullscreenGuideOtherTitle", "fullscreenGuideOtherTitle");
    setText("fullscreenGuideOtherText", "fullscreenGuideOtherText");
    setText("manualTunnelTitle", "manualTunnelTitle");
    setText("manualTunnelDescription", "manualTunnelDescription");
    setText("saveTunnel", "save");
    setText("tunnelHint", "tunnelHintDefault");
    setHtml("permissionTitle", "permissionTitle");
    setText("permissionSectionCopy", "permissionSectionCopy");
    setHtml("permissionPanelNote", "permissionNote");
    setText("permissionBulletReading", "permissionBulletReading");
    setText("permissionBulletSending", "permissionBulletSending");
    setText("permissionBulletPrompts", "permissionBulletPrompts");
    setText("detailsTitle", "detailsTitle");
    setText("detailsSectionCopy", "detailsSectionCopy");
    setText("detailsAvailabilityTitle", "detailsAvailabilityTitle");
    setHtml("detailsAvailabilityIntro", "detailsAvailabilityIntro");
    setText("detailsLimitPower", "detailsLimitPower");
    setText("detailsLimitLid", "detailsLimitLid");
    setText("detailsLimitApp", "detailsLimitApp");
    setText("detailsSyncTitle", "detailsSyncTitle");
    setText("detailsSyncIntro", "detailsSyncIntro");
    setText("detailsSyncLog", "detailsSyncLog");
    setText("detailsSyncConfirm", "detailsSyncConfirm");
    setText("detailsSyncMirror", "detailsSyncMirror");
    setText("detailsSyncSource", "detailsSyncSource");
    setText("detailsMotionTitle", "detailsMotionTitle");
    setText("detailsMotionIntro", "detailsMotionIntro");
    setText("detailsMotionSetting", "detailsMotionSetting");
    setText("detailsMotionData", "detailsMotionData");
    setText("detailsMotionPower", "detailsMotionPower");
    setText("detailsTrustTitle", "detailsTrustTitle");
    setText("detailsTrustIntro", "detailsTrustIntro");
    setText("detailsTrustLocal", "detailsTrustLocal");
    setText("detailsTrustGate", "detailsTrustGate");
    setText("detailsTrustTunnel", "detailsTrustTunnel");
    setText("detailsTrustFirstSend", "detailsTrustFirstSend");
    setText("detailsTrustPermission", "detailsTrustPermission");
    setText("footerSlogan", "footerSlogan");
    setText("footerCreditLabel", "footerCreditLabel");
    setText("footerSignature", "footerSignature");
    if (!latestSetup && !latestErrorMessage) {
      $("mode").innerHTML = escapeHtml(tr("loading"));
      renderPermissionChecking();
    }

    updateLanguageButtons();
  }

  function updateLanguageButtons() {
    if ($("languageSwitch")) {
      $("languageSwitch").setAttribute("data-active-lang", currentLang);
    }

    updateLanguageButton("langEn", "en");
    updateLanguageButton("langZh", "zh");
  }

  function updateLanguageButton(id, lang) {
    var button = $(id);
    var active = currentLang === lang;
    if (!button) {
      return;
    }

    button.className = active ? "isActive" : "";
    button.setAttribute("aria-pressed", active ? "true" : "false");
  }

  function setLanguage(lang) {
    if (lang !== "zh" && lang !== "en") {
      return;
    }

    currentLang = lang;

    try {
      localStorage.setItem(LANGUAGE_STORAGE_KEY, lang);
    } catch (err) {
    }

    applyLanguage();

    if (latestSetup) {
      render(latestSetup);
    } else if (setupErrorActive) {
      renderError(latestErrorMessage);
    }
  }

  function bindLanguageButtons() {
    if ($("langEn")) {
      $("langEn").onclick = function () {
        setLanguage("en");
      };
    }

    if ($("langZh")) {
      $("langZh").onclick = function () {
        setLanguage("zh");
      };
    }
  }

  function xhr(method, path, body, done) {
    var request = new XMLHttpRequest();
    request.open(method, path, true);
    request.onreadystatechange = function () {
      if (request.readyState !== 4) {
        return;
      }

      if (request.status >= 200 && request.status < 300) {
        try {
          done(null, JSON.parse(request.responseText || "{}"));
        } catch (err) {
          done(err);
        }
      } else {
        var error = new Error("HTTP " + request.status);
        try {
          error.payload = JSON.parse(request.responseText || "{}");
          error.detail = error.payload.error || "";
        } catch (parseErr) {
        }
        done(error);
      }
    };

    if (body) {
      request.setRequestHeader("Content-Type", "application/json");
      request.send(JSON.stringify(body));
    } else {
      request.send();
    }
  }

  function requestSetup() {
    xhr("GET", "/api/setup?ts=" + new Date().getTime(), null, function (err, response) {
      if (err) {
        renderError("");
        return;
      }

      latestErrorMessage = "";
      setupErrorActive = false;
      render(response);
    });
  }

  function render(info) {
    var auth = info.auth || {};
    var app = info.app || {};
    var urls = info.urls || {};

    latestSetup = info;
    latestErrorMessage = "";
    setupErrorActive = false;

    $("mode").innerHTML = escapeHtml("v" + (app.version || "0.1.0"));
    renderPin(auth);
    renderUrls(urls);
    renderPermission((info.permissions || {}).remoteControl || {});
    renderChecks(info.checks || []);
    updateActiveSectionNav();
  }

  function renderPin(auth) {
    latestAuth = auth;
    setPinEditor(auth);

    if (!auth.enabled) {
      setPinValue("OFF", "pinText");
      if ($("pinHint")) {
        $("pinHint").innerHTML = escapeHtml(tr("pinDisabled"));
      }
      return;
    }

    if (!auth.pinVisible || !auth.pin) {
      setPinValue(tr("pinHidden"), "pinText");
      if ($("pinHint")) {
        $("pinHint").innerHTML = escapeHtml(tr("pinHiddenHint"));
      }
      return;
    }

    setPinValue(auth.pin, pinClassForValue(auth.pin));
    if ($("pinHint")) {
      $("pinHint").innerHTML = escapeHtml(tr("pinStable", {
        kind: auth.custom ? tr("pinKindCustom") : tr("pinKindLocal")
      }));
    }
  }

  function pinClassForValue(value) {
    var text = String(value || "");

    if (text.length > 8) {
      return "pinText";
    }

    if (text.length > 6) {
      return "pinTight";
    }

    if (text.length > 4) {
      return "pinCompact";
    }

    return "";
  }

  function setPinValue(value, className) {
    var pin = $("pinValue");
    var mode = className || "";

    pin.innerHTML = escapeHtml(value);
    pin.className = mode;
    pin.setAttribute("data-pin-mode", mode);
    schedulePinFit();
  }

  function schedulePinFit() {
    setTimeout(fitPinValue, 0);
    if (window.requestAnimationFrame) {
      window.requestAnimationFrame(fitPinValue);
    } else {
      setTimeout(fitPinValue, 60);
    }
  }

  function fitPinValue() {
    var pin = $("pinValue");
    var modes = ["", "pinCompact", "pinTight", "pinText"];
    var mode;
    var start;
    var i;

    if (!pin) {
      return;
    }

    mode = pin.getAttribute("data-pin-mode") || "";
    start = modes.indexOf(mode);

    if (start < 0) {
      start = 0;
    }

    for (i = start; i < modes.length; i += 1) {
      pin.className = modes[i];

      if (modes[i] === "pinText") {
        return;
      }

      if (pin.scrollWidth <= pin.clientWidth + 1) {
        return;
      }
    }
  }

  function setPinEditor(auth) {
    var disabled = !auth.enabled || !auth.canChangePin;
    $("customPin").disabled = disabled;
    $("savePin").disabled = disabled;
    $("customPin").value = "";

    if (!auth.enabled) {
      $("pinEditHint").innerHTML = escapeHtml(tr("pinProtectionDisabled"));
      return;
    }

    if (!auth.canChangePin) {
      $("pinEditHint").innerHTML = escapeHtml(localizeAuthDisabledReason(auth.changeDisabledReason) || tr("pinConfiguredElsewhere"));
      return;
    }

    $("pinEditHint").innerHTML = escapeHtml(tr("pinSaveHint"));
  }

  function saveCustomPin() {
    var value = $("customPin").value.replace(/^\s+|\s+$/g, "");
    if (!latestAuth || !latestAuth.canChangePin) {
      return;
    }

    if (!/^[0-9]{6}$/.test(value)) {
      $("pinEditHint").innerHTML = escapeHtml(tr("pinTooShort"));
      return;
    }

    $("savePin").disabled = true;
    $("pinEditHint").innerHTML = escapeHtml(tr("saving"));

    xhr("POST", "/api/setup/password", { pin: value }, function (err, response) {
      $("savePin").disabled = false;
      if (err) {
        $("pinEditHint").innerHTML = escapeHtml(localizeAuthDisabledReason(err.detail || "") || tr("pinCouldNotSave"));
        return;
      }

      $("customPin").value = "";
      $("pinEditHint").innerHTML = escapeHtml(tr("pinSaved"));
      if (response && response.setup) {
        render(response.setup);
        $("pinEditHint").innerHTML = escapeHtml(tr("pinSaved"));
      } else {
        requestSetup();
      }
    });
  }

  function constrainPinInput() {
    var input = $("customPin");
    var cleaned;

    if (!input) {
      return;
    }

    cleaned = input.value.replace(/\D/g, "").slice(0, 6);
    if (input.value !== cleaned) {
      input.value = cleaned;
    }
  }

  function saveManualTunnel() {
    var value = $("manualTunnelUrl").value.replace(/^\s+|\s+$/g, "");

    $("saveTunnel").disabled = true;
    $("tunnelHint").innerHTML = escapeHtml(tr("saving"));

    xhr("POST", "/api/setup/remote", { url: value }, function (err, response) {
      $("saveTunnel").disabled = false;
      if (err) {
        $("tunnelHint").innerHTML = escapeHtml(err.detail || tr("tunnelCouldNotSave"));
        return;
      }

      if (response && response.setup) {
        render(response.setup);
      } else {
        requestSetup();
      }

      $("tunnelHint").innerHTML = escapeHtml(value ? tr("tunnelSaved") : tr("tunnelCleared"));
    });
  }

  function renderUrls(urls) {
    var phone = urls.phone || [];
    var manual = urls.manualTunnel || (urls.remote && urls.remote.manualTunnelUrl) || "";
    var qrTargets = buildQrTargets(phone, manual);

    if ($("urls")) {
      $("urls").innerHTML = "";
    }
    $("manualTunnelUrl").value = manual;
    renderQrPanel(qrTargets);
    renderRemoteTips(phone, manual);
    bindCopyButtons();
  }

  function buildQrTargets(phone, manual) {
    var targets = [];
    var seen = {};
    var i;

    function addTarget(label, url, kind, interfaceKind) {
      if (!url || seen[url]) {
        return;
      }

      seen[url] = true;
      targets.push({
        label: label,
        kind: kind || "default",
        interfaceKind: interfaceKind || "",
        url: url
      });
    }

    for (i = 0; i < phone.length; i += 1) {
      addTarget(
        localizeUrlLabel(phone[i].label || tr("urlPhone"), phone[i].interfaceKind || ""),
        phone[i].url || "",
        phone[i].kind || qrKindForLabel(phone[i].label || ""),
        phone[i].interfaceKind || ""
      );
    }

    if (manual) {
      addTarget(tr("urlTunnel"), manual, "tunnel");
    }

    applyQrCardTones(targets);
    return targets;
  }

  function applyQrCardTones(targets) {
    var hasWifiLocal = false;
    var i;

    for (i = 0; i < targets.length; i += 1) {
      if (targets[i].kind === "local" && targets[i].interfaceKind === "wifi") {
        hasWifiLocal = true;
        break;
      }
    }

    for (i = 0; i < targets.length; i += 1) {
      if (targets[i].kind !== "local") {
        continue;
      }

      if (targets[i].interfaceKind === "wifi") {
        targets[i].cardTone = "localPrimary";
        continue;
      }

      targets[i].cardTone = hasWifiLocal ? "wired" : "localPrimary";
    }
  }

  function mapQrUrls(targets) {
    var urls = {};
    var i;

    for (i = 0; i < targets.length; i += 1) {
      if (targets[i].url) {
        urls[targets[i].url] = true;
      }
    }

    return urls;
  }

  function renderQrPanel(targets) {
    var html = "";
    var visibleTargets;
    var i;

    if (!$("qrPanel")) {
      return;
    }

    visibleTargets = qrTargetsWithPrivatePlaceholder(targets || []);

    if (!visibleTargets.length) {
      $("qrPanel").innerHTML = '' +
        '<div class="qrFallback">' +
          '<strong>' + escapeHtml(tr("qrNoUrlTitle")) + '</strong>' +
          '<p>' + escapeHtml(tr("qrNoUrlDetail")) + '</p>' +
        '</div>';
      return;
    }

    html += '<div class="qrCards">';

    for (i = 0; i < visibleTargets.length; i += 1) {
      html += qrCard(visibleTargets[i]);
    }

    html += '</div>';
    html += '<p class="qrDetectedNote">' + escapeHtml(tr("qrDetectedNote")) + '</p>';
    $("qrPanel").innerHTML = html;
  }

  function qrTargetsWithPrivatePlaceholder(targets) {
    var copy = targets.slice();
    var hasPrivate = false;
    var firstTunnelIndex = -1;
    var insertIndex;
    var i;

    for (i = 0; i < copy.length; i += 1) {
      if (copy[i].kind === "tailscale") {
        hasPrivate = true;
      }
      if (copy[i].kind === "tunnel" && firstTunnelIndex === -1) {
        firstTunnelIndex = i;
      }
    }

    if (hasPrivate) {
      return copy;
    }

    insertIndex = firstTunnelIndex === -1 ? copy.length : firstTunnelIndex;
    copy.splice(insertIndex, 0, {
      label: tr("qrPrivateTitle"),
      kind: "tailscale",
      url: "",
      placeholder: true
    });

    return copy;
  }

  function qrIntroHtml() {
    return '' +
      '<div class="qrIntro">' +
        '<p>' + escapeHtml(tr("remoteUseIntro")) + '</p>' +
      '</div>';
  }

  function qrCard(target) {
    var cardClass;
    var qrSvg;
    var steps;
    var title;
    var titleBadge;
    var targetLabel;

    cardClass = "qrCard " + qrCardClass(target.kind, target.interfaceKind, target.cardTone);
    title = tr("qrTitleFor", { label: target.label || tr("urlPhone") });
    titleBadge = target.kind === "tailscale" ? betaBadge() : "";
    targetLabel = tr("qrTarget", { label: target.label || tr("urlPhone") });
    steps = qrStepsForTarget(target);

    if (target.placeholder) {
      return '' +
        '<div class="' + escapeAttr(cardClass) + ' qrCardPlaceholder">' +
          '<div class="qrCodeBox qrCodeBoxPlaceholder">' +
            '<div class="qrPlaceholderMark">' +
              '<span></span><span></span><span></span>' +
            '</div>' +
          '</div>' +
          '<div class="qrCopy">' +
            '<strong>' + escapeHtml(title) + titleBadge + '</strong>' +
            '<p class="qrUrl qrUrlMuted">' + escapeHtml(tr("qrPrivatePlaceholderStatus")) + '</p>' +
            '<p class="qrStep">' + escapeHtml(tr("qrPrivatePlaceholderStep")) + '</p>' +
          '</div>' +
        '</div>';
    }

    qrSvg = makeQrSvg(target.url, targetLabel);
    if (!qrSvg) {
      return '' +
        '<div class="qrFallback">' +
          '<strong>' + escapeHtml(tr("qrTooLongTitle")) + '</strong>' +
          '<p>' + escapeHtml(tr("qrTooLongDetail")) + '</p>' +
          '<button class="qrCopyButton" type="button" data-copy="' + escapeAttr(target.url) + '">' + escapeHtml(tr("qrCopyUrl")) + '</button>' +
        '</div>';
    }

    return '' +
      '<div class="' + escapeAttr(cardClass) + '">' +
        '<div class="qrCodeBox">' + qrSvg + '</div>' +
        '<div class="qrCopy">' +
          '<strong>' + escapeHtml(title) + titleBadge + '</strong>' +
          '<p class="qrUrl">' + escapeHtml(target.url) + '</p>' +
          '<button class="qrCopyButton" type="button" data-copy="' + escapeAttr(target.url) + '">' + escapeHtml(tr("qrCopyUrl")) + '</button>' +
          qrStepsHtml(steps) +
        '</div>' +
      '</div>';
  }

  function qrStepsForTarget(target) {
    var kind = target && target.kind;
    var interfaceKind = target && target.interfaceKind;

    if (kind === "local" && interfaceKind === "wifi") {
      return ["qrWifiLocalStep"];
    }

    if (kind === "local" && (interfaceKind === "ethernet" || interfaceKind === "local")) {
      return ["qrEthernetLocalStep"];
    }

    if (kind === "local") {
      return ["qrLocalStep"];
    }
    if (kind === "tailscale") {
      return ["qrTailscaleStep"];
    }
    if (kind === "tunnel") {
      return ["qrTunnelStep"];
    }
    return ["qrDefaultStep"];
  }

  function qrStepsHtml(steps) {
    var html = "";
    var i;

    if (!steps.length) {
      return "";
    }

    if (steps.length === 1) {
      return '<p class="qrStep">' + escapeHtml(tr(steps[0])) + '</p>';
    }

    for (i = 0; i < steps.length; i += 1) {
      html += '<li>' + escapeHtml(tr(steps[i])) + '</li>';
    }

    return '<ol class="qrSteps">' + html + '</ol>';
  }

  function betaBadge() {
    return '<span class="betaBadge">' + escapeHtml(tr("betaLabel")) + '</span>';
  }

  function qrKindForLabel(label) {
    if (label === "Local network" ||
        label === "Wi-Fi Local network" ||
        label === "Ethernet Local network") {
      return "local";
    }

    if (label === "Tailscale") {
      return "tailscale";
    }

    return "default";
  }

  function qrCardClass(kind, interfaceKind, cardTone) {
    if (kind === "local" && cardTone === "localPrimary") {
      return "qrCardLocalPrimary";
    }

    if (kind === "local" && (cardTone === "wired" || interfaceKind === "ethernet" || interfaceKind === "local")) {
      return "qrCardWired";
    }

    if (kind === "local") {
      return "qrCardLocalPrimary";
    }

    if (kind === "tailscale") {
      return "qrCardTailscale";
    }

    if (kind === "tunnel") {
      return "qrCardTunnel";
    }

    return "qrCardDefault";
  }

  function renderRemoteTips(phone, manual) {
    $("remoteTips").innerHTML = "";
  }

  function renderPermissionChecking() {
    var status = $("permissionStatus");
    if (!status) {
      return;
    }

    status.className = "permissionStatus warn";
    status.innerHTML = '' +
      '<span>' + escapeHtml(tr("permissionCheck")) + '</span>' +
      '<div><strong>' + escapeHtml(tr("permissionCheckingTitle")) + '</strong><em>' + escapeHtml(tr("permissionCheckingDetail")) + '</em></div>' +
      '<button id="openPermissionSettings" type="button">' + escapeHtml(tr("openPermissionSettings")) + '</button>';
    bindPermissionButton();
  }

  function renderPermission(permission) {
    var ok = !!permission.ok;
    var status = $("permissionStatus");
    var detail = localizePermissionDetail(permission.detail || "", ok);

    status.className = "permissionStatus " + (ok ? "ok" : "warn");
    status.innerHTML = '' +
      '<span>' + escapeHtml(ok ? tr("permissionOkBadge") : tr("permissionAllowBadge")) + '</span>' +
      '<div><strong>' + escapeHtml(ok ? tr("permissionReadyTitle") : tr("permissionAllowTitle")) + '</strong><em>' + escapeHtml(detail) + '</em></div>' +
      '<button id="openPermissionSettings" type="button">' + escapeHtml(tr("openPermissionSettings")) + '</button>';

    $("openPermissionSettings").disabled = ok || !permission.available;
    bindPermissionButton();
  }

  function openPermissionSettings() {
    if ($("openPermissionSettings")) {
      $("openPermissionSettings").disabled = true;
    }
    xhr("POST", "/api/setup/permissions/open", {}, function () {
      setTimeout(requestSetup, 1200);
    });
  }

  function bindPermissionButton() {
    if ($("openPermissionSettings")) {
      $("openPermissionSettings").onclick = openPermissionSettings;
    }
  }

  function urlRow(label, value) {
    if (!value) {
      return "";
    }

    return '' +
      '<div class="urlRow">' +
        '<div><strong>' + escapeHtml(label) + '</strong><a href="' + escapeAttr(value) + '">' + escapeHtml(value) + '</a></div>' +
        '<button type="button" data-copy="' + escapeAttr(value) + '">' + escapeHtml(tr("copy")) + '</button>' +
      '</div>';
  }

  function renderChecks(checks) {
    var html = "";
    var i;

    for (i = 0; i < checks.length; i += 1) {
      html += '' +
        '<div class="check ' + (checks[i].ok ? "ok" : "warn") + '">' +
          '<span>' + escapeHtml(checks[i].ok ? tr("badgeOk") : tr("badgeWarn")) + '</span>' +
          '<div><strong>' + escapeHtml(localizeCheckLabel(checks[i])) + '</strong><em>' + escapeHtml(localizeCheckDetail(checks[i])) + '</em></div>' +
        '</div>';
    }

    $("checks").innerHTML = html || '<div class="empty">' + escapeHtml(tr("checksEmpty")) + '</div>';
  }

  function localizeUrlLabel(label, interfaceKind) {
    if (interfaceKind === "wifi") {
      return tr("urlWifiLocalNetwork");
    }

    if (interfaceKind === "ethernet" || (interfaceKind === "local" && label === "Local network")) {
      return tr("urlEthernetLocalNetwork");
    }

    if (label === "Local network") {
      return tr("urlLocalNetwork");
    }

    if (label === "Wi-Fi Local network") {
      return tr("urlWifiLocalNetwork");
    }

    if (label === "Ethernet Local network") {
      return tr("urlEthernetLocalNetwork");
    }

    if (label === "Phone") {
      return tr("urlPhone");
    }

    return label;
  }

  function localizeAuthDisabledReason(detail) {
    if (detail === "PET_AUTH_PIN is set in the environment.") {
      return tr("pinEnvDisabled");
    }

    if (detail === "Use exactly 6 digits.") {
      return tr("pinTooShort");
    }

    return detail || "";
  }

  function localizePermissionDetail(detail, ok) {
    if (!detail) {
      return ok ? tr("permissionDetailAllowed") : tr("permissionDetailDefaultWarn");
    }

    if (detail === tr("permissionDetailServerAllowed") ||
        detail === I18N.en.permissionDetailServerAllowed ||
        detail === "allowed for local remote control") {
      return tr("permissionDetailAllowed");
    }

    if (detail === tr("permissionDetailServerAllow") ||
        detail === I18N.en.permissionDetailServerAllow ||
        detail === "allow Codex ScreenPet Menu.app in Privacy & Security > Accessibility" ||
        detail === "allow Blinky Codex ScreenPet.app in Privacy & Security > Accessibility" ||
        detail === "请在“隐私与安全性 > 辅助功能”里允许 Codex ScreenPet Menu.app" ||
        detail === "请在“隐私与安全性 > 辅助功能”里允许 Blinky Codex ScreenPet.app") {
      return tr("permissionDetailServerAllow");
    }

    if (detail === I18N.en.permissionDetailMacosOnly) {
      return tr("permissionDetailMacosOnly");
    }

    return detail;
  }

  function localizeCheckLabel(check) {
    var key = "check" + toPascalId(check.id || "") + "Label";
    if (hasText(key)) {
      return tr(key);
    }

    return check.label || tr("checkDefault");
  }

  function localizeCheckDetail(check) {
    var detail = check.detail || "";

    if (check.id === "node") {
      return detail;
    }

    if (check.id === "codex-app") {
      return check.ok ? tr("checkInstalled") : tr("checkNotFoundApplications");
    }

    if (check.id === "codex-state" || check.id === "codex-logs") {
      return check.ok ? tr("checkAvailable") : tr("checkNotFound");
    }

    if (check.id === "network") {
      return check.ok ? tr("checkDetected") : tr("checkNoPrivateAddress");
    }

    if (check.id === "remote-control") {
      return check.ok ? tr("checkRemoteControlReady") : tr("checkRemoteControlOptional");
    }

    if (detail === "installed") {
      return tr("checkInstalled");
    }

    if (detail === "not found in /Applications") {
      return tr("checkNotFoundApplications");
    }

    if (detail === "available") {
      return tr("checkAvailable");
    }

    if (detail === "not found") {
      return tr("checkNotFound");
    }

    return detail;
  }

  function localizeNetworkDetail(detail) {
    var urls = latestSetup && latestSetup.urls && latestSetup.urls.phone ? latestSetup.urls.phone : [];
    var labelsByHost = {};
    var parts;
    var output = [];
    var i;
    var host;
    var part;

    for (i = 0; i < urls.length; i += 1) {
      host = hostFromUrl(urls[i].url || "");
      if (host) {
        labelsByHost[host] = localizeUrlLabel(urls[i].label || tr("urlPhone"), urls[i].interfaceKind || "");
      }
    }

    parts = String(detail || "").split(/\s*,\s*/);
    for (i = 0; i < parts.length; i += 1) {
      part = parts[i].replace(/^\s+|\s+$/g, "");
      if (!part) {
        continue;
      }

      output.push((labelsByHost[part] ? labelsByHost[part] + ": " : "") + part);
    }

    return output.length ? output.join("\n") : detail;
  }

  function hostFromUrl(url) {
    var match = String(url).match(/^https?:\/\/([^/:?#]+)/i);
    return match ? match[1] : "";
  }

  function toPascalId(id) {
    var parts = String(id).split("-");
    var output = "";
    var i;

    for (i = 0; i < parts.length; i += 1) {
      if (parts[i]) {
        output += parts[i].charAt(0).toUpperCase() + parts[i].slice(1);
      }
    }

    return output;
  }

  function bindCopyButtons() {
    var buttons = document.querySelectorAll("[data-copy]");
    var i;
    for (i = 0; i < buttons.length; i += 1) {
      buttons[i].onclick = function () {
        copyText(this.getAttribute("data-copy") || "", this);
      };
    }
  }

  function copyText(text, button) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () {
        button.innerHTML = escapeHtml(tr("copied"));
      }).catch(function () {
        fallbackCopy(text, button);
      });
      return;
    }

    fallbackCopy(text, button);
  }

  function fallbackCopy(text, button) {
    var input = document.createElement("input");
    input.value = text;
    document.body.appendChild(input);
    input.select();
    try {
      document.execCommand("copy");
      button.innerHTML = escapeHtml(tr("copied"));
    } catch (err) {
      button.innerHTML = escapeHtml(tr("copy"));
    }
    document.body.removeChild(input);
  }

  var QR_MAX_VERSION = 20;
  var QR_ECC_CODEWORDS_PER_BLOCK_M = [
    0, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26,
    30, 22, 22, 24, 24, 28, 28, 26, 26, 26
  ];
  var QR_NUM_ERROR_CORRECTION_BLOCKS_M = [
    0, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5,
    5, 8, 9, 9, 10, 10, 11, 13, 14, 16
  ];
  var qrGfExp = null;
  var qrGfLog = null;

  function makeQrSvg(text, label) {
    var matrix = makeQrMatrix(text);
    var quiet = 4;
    var size;
    var path = "";
    var y;
    var x;
    var start;

    if (!matrix) {
      return "";
    }

    size = matrix.length + quiet * 2;
    for (y = 0; y < matrix.length; y += 1) {
      x = 0;
      while (x < matrix.length) {
        if (!matrix[y][x]) {
          x += 1;
          continue;
        }

        start = x;
        while (x < matrix.length && matrix[y][x]) {
          x += 1;
        }
        path += "M" + (start + quiet) + " " + (y + quiet) + "h" + (x - start) + "v1H" + (start + quiet) + "z";
      }
    }

    return '' +
      '<svg class="qrSvg" viewBox="0 0 ' + size + ' ' + size + '" role="img" aria-label="' + escapeAttr(label) + '" shape-rendering="crispEdges">' +
        '<rect width="' + size + '" height="' + size + '" fill="#ffffff"></rect>' +
        '<path d="' + path + '" fill="#172033"></path>' +
      '</svg>';
  }

  function makeQrMatrix(text) {
    var bytes = utf8Bytes(text);
    var version = chooseQrVersion(bytes);
    var dataCodewords;
    var allCodewords;
    var base;
    var bestMatrix = null;
    var bestPenalty = Infinity;
    var mask;
    var candidate;
    var penalty;

    if (!version) {
      return null;
    }

    dataCodewords = makeQrDataCodewords(bytes, version);
    allCodewords = addQrErrorCorrectionAndInterleave(dataCodewords, version);
    base = makeQrBase(version);
    drawQrCodewords(base.modules, base.isFunction, allCodewords);

    for (mask = 0; mask < 8; mask += 1) {
      candidate = copyQrMatrix(base.modules);
      applyQrMask(candidate, base.isFunction, mask);
      drawQrFormatBits(candidate, base.isFunction, mask);
      penalty = getQrPenalty(candidate);

      if (penalty < bestPenalty) {
        bestPenalty = penalty;
        bestMatrix = candidate;
      }
    }

    return bestMatrix;
  }

  function chooseQrVersion(bytes) {
    var version;
    var charCountBits;
    var requiredBits;

    for (version = 1; version <= QR_MAX_VERSION; version += 1) {
      charCountBits = version < 10 ? 8 : 16;
      requiredBits = 4 + charCountBits + bytes.length * 8;
      if (requiredBits <= getQrDataCapacityCodewords(version) * 8) {
        return version;
      }
    }

    return 0;
  }

  function makeQrDataCodewords(bytes, version) {
    var bits = [];
    var capacityBits = getQrDataCapacityCodewords(version) * 8;
    var padByte = 0xec;
    var codewords = [];
    var i;
    var value;

    appendQrBits(bits, 4, 4);
    appendQrBits(bits, bytes.length, version < 10 ? 8 : 16);
    for (i = 0; i < bytes.length; i += 1) {
      appendQrBits(bits, bytes[i], 8);
    }

    appendQrBits(bits, 0, Math.min(4, capacityBits - bits.length));
    while (bits.length % 8 !== 0) {
      bits.push(0);
    }

    for (i = 0; i < bits.length; i += 8) {
      value = 0;
      value = (bits[i] << 7) | (bits[i + 1] << 6) | (bits[i + 2] << 5) | (bits[i + 3] << 4) |
        (bits[i + 4] << 3) | (bits[i + 5] << 2) | (bits[i + 6] << 1) | bits[i + 7];
      codewords.push(value);
    }

    while (codewords.length < getQrDataCapacityCodewords(version)) {
      codewords.push(padByte);
      padByte = padByte === 0xec ? 0x11 : 0xec;
    }

    return codewords;
  }

  function appendQrBits(bits, value, length) {
    var i;
    for (i = length - 1; i >= 0; i -= 1) {
      bits.push((value >>> i) & 1);
    }
  }

  function addQrErrorCorrectionAndInterleave(data, version) {
    var numBlocks = QR_NUM_ERROR_CORRECTION_BLOCKS_M[version];
    var blockEccLen = QR_ECC_CODEWORDS_PER_BLOCK_M[version];
    var rawCodewords = Math.floor(getQrNumRawDataModules(version) / 8);
    var numShortBlocks = numBlocks - rawCodewords % numBlocks;
    var shortBlockLen = Math.floor(rawCodewords / numBlocks);
    var shortDataLen = shortBlockLen - blockEccLen;
    var divisor = qrReedSolomonComputeDivisor(blockEccLen);
    var blocks = [];
    var result = [];
    var dataIndex = 0;
    var i;
    var j;
    var dataLen;
    var dat;
    var ecc;

    for (i = 0; i < numBlocks; i += 1) {
      dataLen = shortDataLen + (i < numShortBlocks ? 0 : 1);
      dat = data.slice(dataIndex, dataIndex + dataLen);
      dataIndex += dataLen;
      ecc = qrReedSolomonComputeRemainder(dat, divisor);

      if (i < numShortBlocks) {
        dat.push(0);
      }
      blocks.push(dat.concat(ecc));
    }

    for (i = 0; i < blocks[0].length; i += 1) {
      for (j = 0; j < blocks.length; j += 1) {
        if (i !== shortDataLen || j >= numShortBlocks) {
          result.push(blocks[j][i]);
        }
      }
    }

    return result;
  }

  function makeQrBase(version) {
    var size = version * 4 + 17;
    var modules = [];
    var isFunction = [];
    var align = getQrAlignmentPatternPositions(version);
    var i;
    var j;

    for (i = 0; i < size; i += 1) {
      modules.push([]);
      isFunction.push([]);
      for (j = 0; j < size; j += 1) {
        modules[i].push(false);
        isFunction[i].push(false);
      }
    }

    drawQrFinderPattern(modules, isFunction, 3, 3);
    drawQrFinderPattern(modules, isFunction, size - 4, 3);
    drawQrFinderPattern(modules, isFunction, 3, size - 4);

    for (i = 0; i < align.length; i += 1) {
      for (j = 0; j < align.length; j += 1) {
        if (!((i === 0 && j === 0) || (i === 0 && j === align.length - 1) || (i === align.length - 1 && j === 0))) {
          drawQrAlignmentPattern(modules, isFunction, align[i], align[j]);
        }
      }
    }

    for (i = 0; i < size; i += 1) {
      if (!isFunction[i][6]) {
        setQrFunctionModule(modules, isFunction, 6, i, i % 2 === 0);
      }
      if (!isFunction[6][i]) {
        setQrFunctionModule(modules, isFunction, i, 6, i % 2 === 0);
      }
    }

    drawQrFormatBits(modules, isFunction, 0);
    drawQrVersionBits(modules, isFunction, version);
    return {
      modules: modules,
      isFunction: isFunction
    };
  }

  function drawQrFinderPattern(modules, isFunction, centerX, centerY) {
    var dx;
    var dy;
    var x;
    var y;
    var dist;

    for (dy = -4; dy <= 4; dy += 1) {
      for (dx = -4; dx <= 4; dx += 1) {
        x = centerX + dx;
        y = centerY + dy;
        if (x >= 0 && x < modules.length && y >= 0 && y < modules.length) {
          dist = Math.max(Math.abs(dx), Math.abs(dy));
          setQrFunctionModule(modules, isFunction, x, y, dist !== 2 && dist !== 4);
        }
      }
    }
  }

  function drawQrAlignmentPattern(modules, isFunction, centerX, centerY) {
    var dx;
    var dy;
    for (dy = -2; dy <= 2; dy += 1) {
      for (dx = -2; dx <= 2; dx += 1) {
        setQrFunctionModule(modules, isFunction, centerX + dx, centerY + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
      }
    }
  }

  function drawQrCodewords(modules, isFunction, data) {
    var size = modules.length;
    var bitIndex = 0;
    var direction = -1;
    var x = size - 1;
    var y = size - 1;
    var dx;
    var xx;
    var dark;

    while (x > 0) {
      if (x === 6) {
        x -= 1;
      }

      while (y >= 0 && y < size) {
        for (dx = 0; dx < 2; dx += 1) {
          xx = x - dx;
          if (!isFunction[y][xx] && bitIndex < data.length * 8) {
            dark = ((data[Math.floor(bitIndex / 8)] >>> (7 - bitIndex % 8)) & 1) !== 0;
            modules[y][xx] = dark;
            bitIndex += 1;
          }
        }
        y += direction;
      }

      y -= direction;
      direction = -direction;
      x -= 2;
    }
  }

  function applyQrMask(modules, isFunction, mask) {
    var y;
    var x;
    for (y = 0; y < modules.length; y += 1) {
      for (x = 0; x < modules.length; x += 1) {
        if (!isFunction[y][x] && getQrMaskBit(mask, x, y)) {
          modules[y][x] = !modules[y][x];
        }
      }
    }
  }

  function drawQrFormatBits(modules, isFunction, mask) {
    var size = modules.length;
    var bits = getQrFormatBits(mask);
    var i;

    for (i = 0; i <= 5; i += 1) {
      setQrFunctionModule(modules, isFunction, 8, i, getQrBit(bits, i));
    }
    setQrFunctionModule(modules, isFunction, 8, 7, getQrBit(bits, 6));
    setQrFunctionModule(modules, isFunction, 8, 8, getQrBit(bits, 7));
    setQrFunctionModule(modules, isFunction, 7, 8, getQrBit(bits, 8));
    for (i = 9; i < 15; i += 1) {
      setQrFunctionModule(modules, isFunction, 14 - i, 8, getQrBit(bits, i));
    }

    for (i = 0; i < 8; i += 1) {
      setQrFunctionModule(modules, isFunction, size - 1 - i, 8, getQrBit(bits, i));
    }
    for (i = 8; i < 15; i += 1) {
      setQrFunctionModule(modules, isFunction, 8, size - 15 + i, getQrBit(bits, i));
    }
    setQrFunctionModule(modules, isFunction, 8, size - 8, true);
  }

  function drawQrVersionBits(modules, isFunction, version) {
    var rem = version;
    var bits;
    var i;
    var x;
    var y;

    if (version < 7) {
      return;
    }

    for (i = 0; i < 12; i += 1) {
      rem = (rem << 1) ^ (((rem >>> 11) & 1) ? 0x1f25 : 0);
    }
    bits = (version << 12) | rem;

    for (i = 0; i < 18; i += 1) {
      x = modules.length - 11 + i % 3;
      y = Math.floor(i / 3);
      setQrFunctionModule(modules, isFunction, x, y, getQrBit(bits, i));
      setQrFunctionModule(modules, isFunction, y, x, getQrBit(bits, i));
    }
  }

  function setQrFunctionModule(modules, isFunction, x, y, dark) {
    modules[y][x] = dark;
    isFunction[y][x] = true;
  }

  function getQrFormatBits(mask) {
    var data = mask;
    var rem = data;
    var i;

    for (i = 0; i < 10; i += 1) {
      rem = (rem << 1) ^ (((rem >>> 9) & 1) ? 0x537 : 0);
    }

    return ((data << 10) | rem) ^ 0x5412;
  }

  function getQrBit(value, index) {
    return ((value >>> index) & 1) !== 0;
  }

  function getQrMaskBit(mask, x, y) {
    if (mask === 0) {
      return (x + y) % 2 === 0;
    }
    if (mask === 1) {
      return y % 2 === 0;
    }
    if (mask === 2) {
      return x % 3 === 0;
    }
    if (mask === 3) {
      return (x + y) % 3 === 0;
    }
    if (mask === 4) {
      return (Math.floor(y / 2) + Math.floor(x / 3)) % 2 === 0;
    }
    if (mask === 5) {
      return (x * y) % 2 + (x * y) % 3 === 0;
    }
    if (mask === 6) {
      return ((x * y) % 2 + (x * y) % 3) % 2 === 0;
    }
    return ((x + y) % 2 + (x * y) % 3) % 2 === 0;
  }

  function getQrAlignmentPatternPositions(version) {
    var result = [];
    var numAlign;
    var step;
    var pos;

    if (version === 1) {
      return result;
    }

    numAlign = Math.floor(version / 7) + 2;
    step = Math.ceil((version * 4 + 4) / (numAlign * 2 - 2)) * 2;
    result.push(6);
    for (pos = version * 4 + 10; result.length < numAlign; pos -= step) {
      result.splice(1, 0, pos);
    }

    return result;
  }

  function getQrDataCapacityCodewords(version) {
    return Math.floor(getQrNumRawDataModules(version) / 8) -
      QR_ECC_CODEWORDS_PER_BLOCK_M[version] * QR_NUM_ERROR_CORRECTION_BLOCKS_M[version];
  }

  function getQrNumRawDataModules(version) {
    var result = (16 * version + 128) * version + 64;
    var numAlign;

    if (version >= 2) {
      numAlign = Math.floor(version / 7) + 2;
      result -= (25 * numAlign - 10) * numAlign - 55;
      if (version >= 7) {
        result -= 36;
      }
    }

    return result;
  }

  function copyQrMatrix(matrix) {
    var result = [];
    var i;
    for (i = 0; i < matrix.length; i += 1) {
      result.push(matrix[i].slice());
    }
    return result;
  }

  function getQrPenalty(matrix) {
    return getQrRunPenalty(matrix) +
      getQrBoxPenalty(matrix) +
      getQrFinderPenalty(matrix) +
      getQrBalancePenalty(matrix);
  }

  function getQrRunPenalty(matrix) {
    var size = matrix.length;
    var penalty = 0;
    var horizontal;
    var i;
    var j;
    var runColor;
    var runLength;
    var color;

    for (horizontal = 0; horizontal < 2; horizontal += 1) {
      for (i = 0; i < size; i += 1) {
        runColor = false;
        runLength = 0;
        for (j = 0; j < size; j += 1) {
          color = horizontal ? matrix[i][j] : matrix[j][i];
          if (j === 0 || color !== runColor) {
            if (runLength >= 5) {
              penalty += runLength - 2;
            }
            runColor = color;
            runLength = 1;
          } else {
            runLength += 1;
          }
        }
        if (runLength >= 5) {
          penalty += runLength - 2;
        }
      }
    }

    return penalty;
  }

  function getQrBoxPenalty(matrix) {
    var size = matrix.length;
    var penalty = 0;
    var y;
    var x;
    var color;

    for (y = 0; y < size - 1; y += 1) {
      for (x = 0; x < size - 1; x += 1) {
        color = matrix[y][x];
        if (color === matrix[y][x + 1] && color === matrix[y + 1][x] && color === matrix[y + 1][x + 1]) {
          penalty += 3;
        }
      }
    }

    return penalty;
  }

  function getQrFinderPenalty(matrix) {
    var size = matrix.length;
    var penalty = 0;
    var horizontal;
    var y;
    var x;

    for (horizontal = 0; horizontal < 2; horizontal += 1) {
      for (y = 0; y < size; y += 1) {
        for (x = 0; x < size - 10; x += 1) {
          if (matchesQrFinderPenaltyPattern(matrix, horizontal, x, y)) {
            penalty += 40;
          }
        }
      }
    }

    return penalty;
  }

  function matchesQrFinderPenaltyPattern(matrix, horizontal, x, y) {
    var patternA = [true, false, true, true, true, false, true, false, false, false, false];
    var patternB = [false, false, false, false, true, false, true, true, true, false, true];
    var i;
    var value;
    var matchesA = true;
    var matchesB = true;

    for (i = 0; i < 11; i += 1) {
      value = horizontal ? matrix[y][x + i] : matrix[x + i][y];
      if (value !== patternA[i]) {
        matchesA = false;
      }
      if (value !== patternB[i]) {
        matchesB = false;
      }
    }

    return matchesA || matchesB;
  }

  function getQrBalancePenalty(matrix) {
    var size = matrix.length;
    var dark = 0;
    var total = size * size;
    var y;
    var x;

    for (y = 0; y < size; y += 1) {
      for (x = 0; x < size; x += 1) {
        if (matrix[y][x]) {
          dark += 1;
        }
      }
    }

    return Math.floor(Math.abs(dark * 20 - total * 10) / total) * 10;
  }

  function utf8Bytes(text) {
    var encoded;
    var bytes = [];
    var i;

    try {
      encoded = unescape(encodeURIComponent(text));
    } catch (err) {
      encoded = String(text);
    }

    for (i = 0; i < encoded.length; i += 1) {
      bytes.push(encoded.charCodeAt(i) & 0xff);
    }

    return bytes;
  }

  function setupQrGaloisField() {
    var x = 1;
    var i;

    if (qrGfExp && qrGfLog) {
      return;
    }

    qrGfExp = [];
    qrGfLog = [];
    for (i = 0; i < 255; i += 1) {
      qrGfExp[i] = x;
      qrGfLog[x] = i;
      x <<= 1;
      if (x & 0x100) {
        x ^= 0x11d;
      }
    }
    for (i = 255; i < 512; i += 1) {
      qrGfExp[i] = qrGfExp[i - 255];
    }
  }

  function qrGfMultiply(x, y) {
    setupQrGaloisField();
    if (x === 0 || y === 0) {
      return 0;
    }

    return qrGfExp[qrGfLog[x] + qrGfLog[y]];
  }

  function qrReedSolomonComputeDivisor(degree) {
    var result = [];
    var root = 1;
    var i;
    var j;

    for (i = 0; i < degree - 1; i += 1) {
      result.push(0);
    }
    result.push(1);

    for (i = 0; i < degree; i += 1) {
      for (j = 0; j < result.length; j += 1) {
        result[j] = qrGfMultiply(result[j], root);
        if (j + 1 < result.length) {
          result[j] ^= result[j + 1];
        }
      }
      root = qrGfMultiply(root, 0x02);
    }

    return result;
  }

  function qrReedSolomonComputeRemainder(data, divisor) {
    var result = [];
    var i;
    var j;
    var factor;

    for (i = 0; i < divisor.length; i += 1) {
      result.push(0);
    }

    for (i = 0; i < data.length; i += 1) {
      factor = data[i] ^ result.shift();
      result.push(0);
      for (j = 0; j < result.length; j += 1) {
        result[j] ^= qrGfMultiply(divisor[j], factor);
      }
    }

    return result;
  }

  function renderError(message) {
    var effectiveMessage = message || tr("setupLocalOnlyHint");
    latestSetup = null;
    latestErrorMessage = message || "";
    setupErrorActive = true;
    $("mode").innerHTML = escapeHtml(tr("setupUnavailable"));
    setPinValue(tr("pinHidden"), "pinText");
    if ($("pinHint")) {
      $("pinHint").innerHTML = escapeHtml(effectiveMessage);
    }
    $("customPin").disabled = true;
    $("savePin").disabled = true;
    $("manualTunnelUrl").disabled = true;
    $("saveTunnel").disabled = true;
    if ($("openPermissionSettings")) {
      $("openPermissionSettings").disabled = true;
    }
    $("pinEditHint").innerHTML = "";
    $("tunnelHint").innerHTML = "";
    $("checks").innerHTML = '<div class="check warn"><span>' + escapeHtml(tr("badgeWarn")) + '</span><div><strong>' + escapeHtml(tr("setupLabel")) + '</strong><em>' + escapeHtml(effectiveMessage) + '</em></div></div>';
    $("urls").innerHTML = "";
    if ($("qrPanel")) {
      $("qrPanel").innerHTML = "";
    }
    $("remoteTips").innerHTML = "";
    updateActiveSectionNav();
  }

  function escapeHtml(text) {
    return String(text).replace(/[&<>"']/g, function (ch) {
      return {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
      }[ch];
    });
  }

  function escapeAttr(text) {
    return escapeHtml(text);
  }

  var sectionNavItems = [
    { sectionId: "status", navId: "navReadiness" },
    { sectionId: "pinPanel", navId: "navPassword" },
    { sectionId: "urlsPanel", navId: "navRemote" },
    { sectionId: "permissionPanel", navId: "navDesktop" },
    { sectionId: "detailsPanel", navId: "navNotes" }
  ];
  var activeNavId = "";

  function setupSectionNavigation() {
    var i;
    var link;

    for (i = 0; i < sectionNavItems.length; i += 1) {
      link = $(sectionNavItems[i].navId);
      if (link) {
        link.onclick = handleSectionNavClick;
      }
    }

    updateActiveSectionNav();

    if (window.addEventListener) {
      window.addEventListener("scroll", updateActiveSectionNav, { passive: true });
      window.addEventListener("resize", updateActiveSectionNav);
    } else if (window.attachEvent) {
      window.attachEvent("onscroll", updateActiveSectionNav);
      window.attachEvent("onresize", updateActiveSectionNav);
    }
  }

  function handleSectionNavClick(event) {
    var href = this.getAttribute("href") || "";
    var targetId = href.charAt(0) === "#" ? href.slice(1) : "";
    var target = targetId ? $(targetId) : null;

    if (!target) {
      return true;
    }

    if (event && event.preventDefault) {
      event.preventDefault();
    } else if (event) {
      event.returnValue = false;
    }

    setActiveSectionNav(this.id);

    try {
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (err) {
      window.location.hash = href;
    }

    return false;
  }

  function updateActiveSectionNav() {
    var currentNavId = activeSectionNavId();
    setActiveSectionNav(currentNavId);
  }

  function activeSectionNavId() {
    var topBar = $("setupTopBar");
    var viewportHeight = window.innerHeight || (document.documentElement && document.documentElement.clientHeight) || 720;
    var anchor = (topBar ? topBar.getBoundingClientRect().height : 0) + Math.min(120, Math.max(72, viewportHeight * 0.14));
    var bestNavId = "";
    var bestDistance = Infinity;
    var firstTop = null;
    var firstBottom = null;
    var documentHeight;
    var section;
    var rect;
    var distance;
    var i;

    documentHeight = Math.max(
      document.body ? document.body.scrollHeight : 0,
      document.documentElement ? document.documentElement.scrollHeight : 0
    );

    if (window.pageYOffset + window.innerHeight >= documentHeight - 2) {
      return sectionNavItems[sectionNavItems.length - 1].navId;
    }

    for (i = 0; i < sectionNavItems.length; i += 1) {
      section = $(sectionNavItems[i].sectionId);
      if (!section) {
        continue;
      }

      rect = section.getBoundingClientRect();
      if (firstTop === null) {
        firstTop = rect.top;
        firstBottom = rect.bottom;
      }

      if (rect.top <= anchor && rect.bottom > anchor) {
        return sectionNavItems[i].navId;
      }

      distance = Math.abs(rect.top - anchor);
      if (rect.top <= anchor && distance < bestDistance) {
        bestDistance = distance;
        bestNavId = sectionNavItems[i].navId;
      }
    }

    if (firstTop !== null && firstTop > anchor) {
      if (firstTop < viewportHeight && firstBottom > (topBar ? topBar.getBoundingClientRect().height : 0)) {
        return sectionNavItems[0].navId;
      }

      return "";
    }

    return bestNavId;
  }

  function setActiveSectionNav(navId) {
    var i;
    var link;
    var isActive;

    if (activeNavId === navId) {
      return;
    }

    activeNavId = navId || "";

    for (i = 0; i < sectionNavItems.length; i += 1) {
      link = $(sectionNavItems[i].navId);
      if (!link) {
        continue;
      }

      isActive = link.id === activeNavId;
      link.className = isActive ? "isActive" : "";
      if (isActive) {
        link.setAttribute("aria-current", "true");
        scrollActiveNavIntoView(link);
      } else {
        link.removeAttribute("aria-current");
      }
    }
  }

  function scrollActiveNavIntoView(link) {
    var nav = link && link.parentNode;
    var linkLeft;
    var linkRight;
    var targetLeft;

    if (!nav || nav.scrollWidth <= nav.clientWidth) {
      return;
    }

    linkLeft = link.offsetLeft;
    linkRight = linkLeft + link.offsetWidth;

    if (linkLeft < nav.scrollLeft) {
      targetLeft = Math.max(0, linkLeft - 12);
    } else if (linkRight > nav.scrollLeft + nav.clientWidth) {
      targetLeft = Math.min(nav.scrollWidth - nav.clientWidth, linkRight - nav.clientWidth + 12);
    } else {
      return;
    }

    try {
      nav.scrollTo({ left: targetLeft, behavior: "smooth" });
    } catch (err) {
      nav.scrollLeft = targetLeft;
    }
  }

  bindLanguageButtons();
  applyLanguage();
  refreshSetupFavicon();
  setupSectionNavigation();

  $("savePin").onclick = saveCustomPin;
  $("saveTunnel").onclick = saveManualTunnel;
  bindPermissionButton();
  $("customPin").onkeydown = function (event) {
    event = event || window.event;
    if (event.key === "Enter" || event.keyCode === 13) {
      saveCustomPin();
      return false;
    }
    return true;
  };
  $("customPin").oninput = constrainPinInput;
  $("manualTunnelUrl").onkeydown = function (event) {
    event = event || window.event;
    if (event.key === "Enter" || event.keyCode === 13) {
      saveManualTunnel();
      return false;
    }
    return true;
  };

  if (window.addEventListener) {
    window.addEventListener("resize", schedulePinFit);
  } else if (window.attachEvent) {
    window.attachEvent("onresize", schedulePinFit);
  }

  requestSetup();
}());
