(function () {
  var currentState = "idle";
  var startedAt = null;
  var lastSeenAt = new Date().getTime();
  var latestBoard = null;
  var selectedTaskId = "";
  var CARD_SNIPPET_LIMIT = 2;
  var SNIPPET_LIMIT = 15;
  var typingViewportHeight = 0;
  var typingViewportWidth = 0;
  var AUTH_STORAGE_KEY = "codexMobilePetPin";
  var authRequired = false;
  var authUnlocked = false;
  var authPin = storageGet(AUTH_STORAGE_KEY);
  var pollInFlight = false;
  var pollInFlightAt = 0;
  var panelOpeningTimer = null;
  var sendHintTimer = null;
  var INSTRUCTION_PLACEHOLDER = "Type";

  function $(id) {
    return document.getElementById(id);
  }

  function updateViewportLayout() {
    var viewport = window.visualViewport || null;
    var width = Math.round((viewport && viewport.width) || window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth || 320);
    var height = Math.round((viewport && viewport.height) || window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight || 480);
    var isScrollableLandscape;
    var stage = $("stage");

    if (typingViewportHeight && instructionInputIsFocused()) {
      width = typingViewportWidth || width;
      height = Math.max(height, typingViewportHeight);
    }

    updateLandscapePetFit(width, height);
    isScrollableLandscape = width > height && width >= 460 && height <= 520;

    document.documentElement.style.height = height + "px";
    document.body.style.height = height + "px";

    if (stage) {
      stage.style.width = width + "px";
      stage.style.height = height + "px";
      stage.style.minHeight = isScrollableLandscape ? height + "px" : "";
    }
  }

  function updateLandscapePetFit(width, height) {
    var root = document.documentElement;
    var isLandscapeHome = width > height && width >= 460 && height <= 520;
    var bottomPad;
    var headerBottom;
    var leftWidth;
    var maxContentWidth;
    var maxHeightScale;
    var maxWidthScale;
    var maxScale;
    var metaNode;
    var metaRect;
    var petHeight;
    var scale;
    var top;
    var usableHeight;

    if (!root) {
      return;
    }

    if (!isLandscapeHome) {
      root.style.removeProperty("--landscape-pet-scale");
      root.style.removeProperty("--landscape-pet-top");
      root.style.removeProperty("--landscape-stage-min-height");
      return 0;
    }

    leftWidth = width * 0.5;
    headerBottom = width >= 860 ? 70 : width >= 700 ? 62 : width >= 600 ? 52 : 48;
    if (height <= 330) {
      headerBottom = width >= 600 ? 50 : 46;
    }
    if (height <= 290) {
      headerBottom = 42;
    }
    metaNode = $("connectionMeta");
    if (metaNode && metaNode.getBoundingClientRect) {
      metaRect = metaNode.getBoundingClientRect();
      if (metaRect && metaRect.bottom > 0) {
        headerBottom = Math.max(headerBottom, Math.ceil(metaRect.bottom) + (height <= 330 ? 4 : 6));
      }
    }

    bottomPad = height <= 300 ? 6 : 10;
    petHeight = 188;
    usableHeight = Math.max(110, height - headerBottom - bottomPad);
    maxContentWidth = width >= 700 ? 176 : 168;
    maxHeightScale = usableHeight / petHeight;
    maxWidthScale = (leftWidth - (width >= 700 ? 36 : 26)) / maxContentWidth;
    maxScale = width >= 860 ? 2.12 : width >= 700 ? 1.95 : width >= 600 ? 1.72 : 1.5;

    scale = clamp(Math.min(maxHeightScale, maxWidthScale, maxScale), 0.74, maxScale);
    top = headerBottom + Math.max(0, Math.floor((usableHeight - (petHeight * scale)) / 2));

    root.style.setProperty("--landscape-pet-scale", String(Math.round(scale * 1000) / 1000));
    root.style.setProperty("--landscape-pet-top", top + "px");
    root.style.setProperty("--landscape-stage-min-height", height + "px");
    return height;
  }

  function instructionInputIsFocused() {
    return document.activeElement && document.activeElement.id === "instructionInput" && $("taskPanel").className !== "hidden";
  }

  function lockTypingViewport() {
    typingViewportWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth || 320;
    typingViewportHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight || 480;
    updateViewportLayout();
  }

  function unlockTypingViewport() {
    typingViewportWidth = 0;
    typingViewportHeight = 0;
    setTimeout(updateViewportLayout, 120);
    setTimeout(updateViewportLayout, 360);
  }

  function setSendHint(html) {
    if (sendHintTimer) {
      clearTimeout(sendHintTimer);
      sendHintTimer = null;
    }
    $("sendHint").innerHTML = html || "";
  }

  function clearSendHintSoon(expectedHtml) {
    if (sendHintTimer) {
      clearTimeout(sendHintTimer);
    }
    sendHintTimer = setTimeout(function () {
      sendHintTimer = null;
      if ($("sendHint").innerHTML === expectedHtml && !$("instructionInput").value) {
        $("sendHint").innerHTML = "";
      }
    }, 2400);
  }

  function clearSentHintOnTyping() {
    var hint = $("sendHint").innerHTML;
    if (sendHintTimer) {
      clearTimeout(sendHintTimer);
      sendHintTimer = null;
    }
    if (hint.indexOf("Sent") === 0 || hint.indexOf("Queued") === 0 || hint.indexOf("Demo") === 0) {
      $("sendHint").innerHTML = "";
    }
  }

  function prepareInstructionInput(input) {
    if (!input) {
      return null;
    }
    input.value = "";
    input.defaultValue = "";
    input.placeholder = INSTRUCTION_PLACEHOLDER;
    input.setAttribute("placeholder", INSTRUCTION_PLACEHOLDER);
    input.scrollTop = 0;
    input.scrollLeft = 0;
    return input;
  }

  function bindInstructionInput(input) {
    input = input || $("instructionInput");
    if (!input) {
      return null;
    }
    input.onfocus = lockTypingViewport;
    input.onblur = unlockTypingViewport;
    input.oninput = clearSentHintOnTyping;
    return input;
  }

  function rebuildInstructionInputAfterSend(input) {
    var clone;

    input = input || $("instructionInput");
    if (!input || !input.parentNode) {
      return prepareInstructionInput(input);
    }
    if (document.activeElement === input) {
      input.blur();
    }
    clone = input.cloneNode(false);
    prepareInstructionInput(clone);
    bindInstructionInput(clone);
    input.parentNode.replaceChild(clone, input);
    return clone;
  }

  function resetInstructionComposerAfterSend(hint) {
    var input = $("instructionInput");
    prepareInstructionInput(input);
    try {
      input.setSelectionRange(0, 0);
    } catch (err) {
      // Old mobile browsers may reject selection changes on an unfocused textarea.
    }
    rebuildInstructionInputAfterSend(input);
    unlockTypingViewport();
    setSendHint(hint);
    clearSendHintSoon(hint);
    setTimeout(function () {
      prepareInstructionInput($("instructionInput"));
    }, 80);
  }

  function xhr(method, path, body, done) {
    var request = new XMLHttpRequest();
    request.open(method, path, true);
    if (authPin) {
      request.setRequestHeader("X-Codex-Pet-Pin", authPin);
    }
    request.onreadystatechange = function () {
      if (request.readyState === 4) {
        if (request.status >= 200 && request.status < 300) {
          try {
            done(null, JSON.parse(request.responseText));
          } catch (err) {
            done(err);
          }
        } else {
          var error = new Error("HTTP " + request.status);
          error.status = request.status;
          try {
            error.payload = JSON.parse(request.responseText || "{}");
            error.detail = error.payload.detail || error.payload.error || "";
            error.authRequired = !!error.payload.authRequired;
          } catch (parseErr) {
          }
          done(error);
        }
      }
    };
    if (body) {
      request.setRequestHeader("Content-Type", "application/json");
      request.send(JSON.stringify(body));
    } else {
      request.send();
    }
  }

  function storageGet(key) {
    try {
      return window.localStorage ? String(window.localStorage.getItem(key) || "") : "";
    } catch (err) {
      return "";
    }
  }

  function storageSet(key, value) {
    try {
      if (window.localStorage) {
        window.localStorage.setItem(key, value);
      }
    } catch (err) {
    }
  }

  function storageRemove(key) {
    try {
      if (window.localStorage) {
        window.localStorage.removeItem(key);
      }
    } catch (err) {
    }
  }

  function showAuthGate(message) {
    authRequired = true;
    authUnlocked = false;
    $("authGate").className = "";
    $("authHint").innerHTML = message ? escapeHtml(message) : "";
    $("stateText").innerHTML = "Locked";
    $("signal").className = "offline";
    setTimeout(function () {
      $("authPin").focus();
    }, 50);
  }

  function hideAuthGate() {
    $("authGate").className = "authHidden";
    $("authHint").innerHTML = "";
  }

  function unlockWithPin(pin, silent) {
    pin = String(pin || "").replace(/^\s+|\s+$/g, "");
    if (!pin) {
      if (!silent) {
        $("authHint").innerHTML = "Enter the phone password from your Mac.";
      }
      return;
    }

    $("authUnlock").disabled = true;
    $("authHint").innerHTML = silent ? "" : "Checking...";

    xhr("POST", "/api/auth/unlock", { pin: pin }, function (err, response) {
      $("authUnlock").disabled = false;
      if (err) {
        authPin = "";
        storageRemove(AUTH_STORAGE_KEY);
        showAuthGate("Wrong password. Check the setup page on your Mac.");
        return;
      }

      authPin = pin;
      authRequired = !!(response && response.auth && response.auth.enabled);
      authUnlocked = true;
      storageSet(AUTH_STORAGE_KEY, pin);
      hideAuthGate();
      poll();
    });
  }

  function initAuth() {
    xhr("GET", "/api/auth/status?ts=" + new Date().getTime(), null, function (err, response) {
      var enabled;
      if (err) {
        showAuthGate("Unable to check password. Is the Mac server running?");
        return;
      }

      enabled = !!(response && response.auth && response.auth.enabled);
      authRequired = enabled;
      if (!enabled) {
        authUnlocked = true;
        hideAuthGate();
        poll();
        return;
      }

      if (authPin) {
        unlockWithPin(authPin, true);
      } else {
        showAuthGate("Enter the phone password shown on your Mac.");
      }
    });
  }

  function applyStatus(status) {
    var state = status.state || "idle";
    currentState = state;
    startedAt = parseDate(status.startedAt) || new Date();
    lastSeenAt = new Date().getTime();

    document.body.className = "state-" + state;
    $("stateText").innerHTML = "Connected";
    $("title").innerHTML = escapeHtml(status.title || "Blinky Codex ScreenPet");
    $("message").innerHTML = escapeHtml(status.message || "");
    $("detail").innerHTML = escapeHtml(status.detail || "");
    $("progressFill").style.width = clamp(status.progress || 0, 0, 100) + "%";
    $("signal").className = "online";
  }

  function applyBoard(board) {
    var status = board.status || {};
    var tasks = board.tasks || [];
    var pendingCount = Number(board.pendingInstructionCount) || 0;
    var workCount = countTasks(tasks, { working: true, thinking: true });
    var waitCount = countTasks(tasks, { waiting: true });
    latestBoard = board;

    applyStatus(status);
    applyConnection(board.connection);
    $("runningCount").innerHTML = "Working " + workCount + (waitCount ? " · Waiting " + waitCount : "") + " · Recent " + (Number(board.totalCount) || 0) + (pendingCount ? " · Q " + pendingCount : "");
    $("boardUpdated").innerHTML = "";
    renderTasks(tasks);
    refreshPanel();
  }

  function applyConnection(connection) {
    var node = $("connectionMeta");
    var device;
    var address;
    var betaActive;
    var betaLabel;

    if (!node) {
      return;
    }

    connection = connection || {};
    betaActive = remoteSendBetaActive(connection);
    device = compactMeta(connection.deviceName || "This Mac", betaActive ? 24 : 34);
    address = compactMeta(connection.address || connection.host || connection.url || "local", betaActive ? 22 : 42);
    betaLabel = betaActive ? ' <span class="betaBadge connectionBeta">Remote Send Beta</span>' : "";

    node.innerHTML = escapeHtml(device + " · " + address) + betaLabel;
    node.title = device + " · " + address + (betaLabel ? " · Remote Send Beta" : "");
  }

  function remoteSendBetaActive(connection) {
    var label = String(connection && connection.networkLabel || "").toLowerCase();
    var address = String(connection && (connection.address || connection.host || connection.url) || "").toLowerCase();

    if (label === "tailscale" || label === "private network") {
      return true;
    }
    return /^100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\./.test(address);
  }

  function compactMeta(value, maxLength) {
    var text = String(value || "").replace(/^\s+|\s+$/g, "");

    text = text.replace(/^https?:\/\//i, "");
    text = text.replace(/\/.*$/, "");
    text = text.replace(/:8788$/, "");
    text = text.replace(/\s+/g, " ");

    if (!text) {
      return "local";
    }

    maxLength = Number(maxLength) || 36;
    if (text.length > maxLength) {
      return text.slice(0, maxLength - 1) + "...";
    }

    return text;
  }

  function countTasks(tasks, states) {
    var count = 0;
    var i;
    for (i = 0; i < tasks.length; i += 1) {
      if (states[tasks[i].state]) {
        count += 1;
      }
    }
    return count;
  }

  function renderTasks(tasks) {
    var visible = [];
    var i;
    var html = "";

    for (i = 0; i < tasks.length; i += 1) {
      visible.push(tasks[i]);
    }

    if (!visible.length) {
      $("taskList").innerHTML = '<div class="empty">No running tasks</div>';
      return;
    }

    for (i = 0; i < visible.length; i += 1) {
      html += taskHtml(visible[i]);
    }

    $("taskList").innerHTML = html;
  }

  function taskHtml(task) {
    var state = task.state || "idle";
    var progress = clamp(task.progress || 0, 0, 100);
    var pending = Number(task.pendingInstructions) || 0;
    var meta = task.timeLabel || (progress + "%");
    var project = task.projectLabel ? '<div class="taskProject">' + escapeHtml(task.projectLabel) + '</div>' : "";
    return '' +
      '<div class="taskItem task-' + escapeAttr(state) + '" data-task-id="' + escapeAttr(task.id || "current") + '">' +
        '<div class="taskLine">' +
          '<span class="taskDot">' + escapeHtml(labelFor(state)) + '</span>' +
          '<strong>' + escapeHtml(task.title || "Untitled task") + '</strong>' +
          '<em>' + escapeHtml(meta) + '</em>' +
        '</div>' +
        project +
        '<div class="taskSnippets">' + snippetsHtml(task.snippets, task.message || task.detail || "", CARD_SNIPPET_LIMIT) + '</div>' +
        (pending ? '<div class="taskPending">' + pending + '</div>' : '') +
        '<div class="miniTrack"><span style="width:' + progress + '%"></span></div>' +
      '</div>';
  }

  function snippetsHtml(snippets, fallback, limit) {
    var list = snippets || [];
    var html = "";
    var i;
    var role;
    var max = Math.max(1, Number(limit) || SNIPPET_LIMIT);

    if (!list.length && fallback) {
      list = [{ role: "user", text: fallback }];
    }

    if (list.length > max) {
      list = list.slice(list.length - max);
    }

    for (i = 0; i < list.length && i < max; i += 1) {
      role = list[i].role === "assistant" ? "assistant" : "user";
      html += '<div>' + roleBadgeHtml(role) + escapeHtml(list[i].text || "") + '</div>';
    }

    return html || '<div><span class="roleBadge roleEmpty">-</span>No recent messages</div>';
  }

  function panelMessagesHtml(snippets, fallback) {
    var list = snippets || [];
    var html = "";
    var i;
    var role;
    var roleClass;
    var text;

    if (!list.length && fallback) {
      list = [{ role: "assistant", text: fallback }];
    }

    for (i = 0; i < list.length; i += 1) {
      role = list[i].role === "assistant" ? "assistant" : "user";
      roleClass = role === "assistant" ? "Codex" : "Me";
      text = list[i].text || "";

      html +=
        '<article class="panelMessageItem panelMessage' + roleClass + '">' +
          '<div class="panelMessageRole">' + escapeHtml(panelRoleLabel(role)) + '</div>' +
          '<div class="panelMessageText">' + escapeHtml(text) + '</div>' +
        '</article>';
    }

    if (!html) {
      html =
        '<article class="panelMessageItem panelMessageEmpty">' +
          '<div class="panelMessageRole">Task</div>' +
          '<div class="panelMessageText">No recent messages</div>' +
        '</article>';
    }

    return '<div class="panelMessages">' + html + '</div>';
  }

  function panelSnippetsForTask(task) {
    if (task && task.detailSnippets && task.detailSnippets.length) {
      return task.detailSnippets;
    }
    return task && task.snippets ? task.snippets : [];
  }

  function panelRoleLabel(role) {
    if (role === "assistant") {
      return "Codex";
    }
    return "Me";
  }

  function roleBadgeHtml(role) {
    if (role === "assistant") {
      return '<span class="roleBadge roleCodex" aria-label="Codex"></span>';
    }
    return '<span class="roleBadge roleMe">ME</span>';
  }

  function taskById(id) {
    var tasks = latestBoard && latestBoard.tasks ? latestBoard.tasks : [];
    var i;
    for (i = 0; i < tasks.length; i += 1) {
      if (tasks[i].id === id) {
        return tasks[i];
      }
    }
    return null;
  }

  function refreshPanel() {
    var task;
    if (!selectedTaskId || $("taskPanel").className === "hidden") {
      return;
    }

    task = taskById(selectedTaskId);
    if (!task) {
      closeTaskPanel();
      return;
    }

    fillPanel(task, false);
  }

  function openTaskPanel(task, sourceNode) {
    selectedTaskId = task.id || "current";
    preparePanelOpenMotion(sourceNode);
    $("taskPanel").className = "panelOpening";
    fillPanel(task, true);
    setSendHint("");
    $("instructionInput").value = "";
    markPanelOpening();
    markTaskItemOpening(sourceNode);
  }

  function closeTaskPanel() {
    $("instructionInput").blur();
    unlockTypingViewport();
    selectedTaskId = "";
    if (panelOpeningTimer) {
      clearTimeout(panelOpeningTimer);
      panelOpeningTimer = null;
    }
    $("taskPanel").className = "hidden";
  }

  function fillPanel(task, forceScrollToBottom) {
    var message = $("panelMessage");
    var shouldScrollToBottom = forceScrollToBottom || panelMessageIsNearBottom();
    var previousScrollTop = message ? message.scrollTop : 0;
    var pending = Number(task.pendingInstructions) || 0;
    var state = task.state || "idle";
    $("taskPanel").className = "panel-" + escapeAttr(state) + panelMotionClass();
    $("panelState").innerHTML = panelLabelFor(state);
    $("panelTitle").innerHTML = escapeHtml(task.title || "Untitled task");
    $("panelMeta").innerHTML = escapeHtml((task.sourceLabel || "Task") + " · " + (task.timeLabel || shortTime(task.updatedAt)) + " · " + (task.progress || 0) + "%" + (pending ? " · " + pending + " queued" : ""));
    message.innerHTML = panelMessagesHtml(panelSnippetsForTask(task), task.message || task.detail || "No detail yet.");
    if (shouldScrollToBottom) {
      scrollPanelMessageToBottom();
    } else {
      message.scrollTop = previousScrollTop;
    }
  }

  function preparePanelOpenMotion(sourceNode) {
    var panel = $("taskPanel");
    var rect = sourceNode && sourceNode.getBoundingClientRect ? sourceNode.getBoundingClientRect() : null;
    var viewportWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth || 320;
    var viewportHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight || 480;
    var targetWidth = Math.max(viewportWidth - 28, 1);
    var targetHeight = Math.max(viewportHeight - 112, 1);
    var originX = viewportWidth / 2;
    var originY = viewportHeight / 2;
    var scale = 0.94;
    var scaleX = 0.92;
    var scaleY = 0.24;

    if (rect) {
      originX = rect.left + rect.width / 2;
      originY = rect.top + rect.height / 2;
      scaleX = clamp(rect.width / targetWidth, 0.58, 0.98);
      scaleY = clamp(rect.height / targetHeight, 0.16, 0.44);
      scale = clamp(rect.width / targetWidth, 0.86, 0.97);
    }

    panel.style.setProperty("--detail-open-x", Math.round(originX - viewportWidth / 2) + "px");
    panel.style.setProperty("--detail-open-y", Math.round(originY - viewportHeight / 2) + "px");
    panel.style.setProperty("--detail-open-scale", String(Math.round(scale * 1000) / 1000));
    panel.style.setProperty("--detail-open-scale-x", String(Math.round(scaleX * 1000) / 1000));
    panel.style.setProperty("--detail-open-scale-y", String(Math.round(scaleY * 1000) / 1000));
  }

  function panelMotionClass() {
    return $("taskPanel").className.indexOf("panelOpening") !== -1 ? " panelOpening" : "";
  }

  function markPanelOpening() {
    var panel = $("taskPanel");
    if (panelOpeningTimer) {
      clearTimeout(panelOpeningTimer);
    }
    panelOpeningTimer = setTimeout(function () {
      panel.className = panel.className.replace(/\s*panelOpening\b/g, "");
      panelOpeningTimer = null;
    }, 520);
  }

  function markTaskItemOpening(sourceNode) {
    if (!sourceNode) {
      return;
    }
    sourceNode.className = addClassName(sourceNode.className, "taskItemOpening");
    setTimeout(function () {
      sourceNode.className = removeClassName(sourceNode.className, "taskItemOpening");
    }, 320);
  }

  function addClassName(className, name) {
    className = String(className || "");
    return className.indexOf(name) === -1 ? (className + " " + name).replace(/^\s+|\s+$/g, "") : className;
  }

  function removeClassName(className, name) {
    return String(className || "").replace(new RegExp("\\s*" + name + "\\b", "g"), "").replace(/^\s+|\s+$/g, "");
  }

  function panelCopyText(task) {
    var snippets = panelSnippetsForTask(task);
    var fallback = task ? (task.message || task.detail || "") : "";
    var lines = [];
    var list;
    var i;
    var role;
    var text;

    if (!snippets.length && fallback) {
      snippets = [{ role: "user", text: fallback }];
    }

    list = snippets.length > SNIPPET_LIMIT ? snippets.slice(snippets.length - SNIPPET_LIMIT) : snippets;
    for (i = 0; i < list.length; i += 1) {
      text = String(list[i].text || "").replace(/\s+$/g, "");
      if (!text) {
        continue;
      }
      role = list[i].role === "assistant" ? "Codex" : "Me";
      lines.push(role + ": " + text);
    }

    return lines.join("\n\n");
  }

  function copyPanelMessages() {
    var task = selectedTaskId ? taskById(selectedTaskId) : null;
    var text = panelCopyText(task);

    if (!text) {
      $("sendHint").innerHTML = "Nothing to copy.";
      return;
    }

    copyText(text, function (ok) {
      $("sendHint").innerHTML = ok ? "Copied conversation." : "Copy failed. Long-press the message text to select it.";
    });
  }

  function copyText(text, done) {
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(function () {
        done(true);
      }).catch(function () {
        done(fallbackCopyText(text));
      });
      return;
    }
    done(fallbackCopyText(text));
  }

  function fallbackCopyText(text) {
    var area = document.createElement("textarea");
    var ok = false;

    area.value = text;
    area.setAttribute("readonly", "readonly");
    area.style.position = "fixed";
    area.style.left = "-9999px";
    area.style.top = "0";
    area.style.opacity = "0";
    document.body.appendChild(area);
    area.focus();
    area.select();
    if (area.setSelectionRange) {
      area.setSelectionRange(0, area.value.length);
    }
    try {
      ok = document.execCommand("copy");
    } catch (err) {
      ok = false;
    }
    document.body.removeChild(area);
    return ok;
  }

  function panelMessageIsNearBottom() {
    var message = $("panelMessage");
    if (!message) {
      return true;
    }
    return message.scrollHeight - message.clientHeight - message.scrollTop <= 8;
  }

  function scrollPanelMessageToBottom() {
    var message = $("panelMessage");
    if (!message) {
      return;
    }
    message.scrollTop = message.scrollHeight;
    setTimeout(function () {
      message.scrollTop = message.scrollHeight;
    }, 0);
  }

  function sendInstruction() {
    var text = $("instructionInput").value;
    if (authRequired && !authUnlocked) {
      showAuthGate("Unlock before sending instructions.");
      return;
    }
    if (!selectedTaskId) {
      return;
    }

    text = text.replace(/^\s+|\s+$/g, "");
    if (!text) {
      setSendHint("Type something first.");
      return;
    }

    $("sendInstruction").disabled = true;
    setSendHint("Sending...");

    xhr("POST", "/api/instructions", {
      taskId: selectedTaskId,
      text: text
    }, function (err, response) {
      $("sendInstruction").disabled = false;
      if (err) {
        setSendHint(escapeHtml(failHint(err)));
        if (err.payload && err.payload.board) {
          applyBoard(err.payload.board);
        }
        return;
      }

      resetInstructionComposerAfterSend(sentHint(response));
      if (response && response.board) {
        applyBoard(response.board);
      } else {
        poll();
      }
      setTimeout(poll, 1200);
    });
  }

  function sentHint(response) {
    var method = response && response.instruction ? String(response.instruction.deliveryMethod || "") : "";
    if (!response || response.delivery !== "sent") {
      return "Queued · waiting";
    }
    if (method === "desktop-ui") {
      return "Sent · mirrored";
    }
    if (method === "demo") {
      return "Demo · recorded";
    }
    if (method === "desktop-queued-start" || method === "codex-rpc-queued-start" || method.indexOf("queue") !== -1) {
      return "Queued · confirmed";
    }
    return "Sent · confirmed";
  }

  function failHint(err) {
    var text = err && err.detail ? String(err.detail) : "";
    if (err && err.payload && err.payload.permissionRequired) {
      return "Mac approval needed. Check Mac, then retry.";
    }
    if (text.length > 64) {
      text = text.slice(0, 63) + "...";
    }
    return text ? "Send failed: " + text : "Send failed.";
  }

  function clickTask(event) {
    var target = event.target || event.srcElement;
    var node = target;
    var id;

    while (node && node !== $("taskList")) {
      if (node.getAttribute && node.getAttribute("data-task-id")) {
        id = node.getAttribute("data-task-id");
        openTaskPanel(taskById(id) || { id: id, title: "Task" }, node);
        return;
      }
      node = node.parentNode;
    }
  }

  function labelFor(state) {
    var labels = {
      idle: "READY",
      thinking: "thinking",
      working: "working",
      waiting: "waiting",
      done: "DONE",
      error: "ERROR",
      offline: "OFFLINE"
    };
    return labels[state] || "READY";
  }

  function panelLabelFor(state) {
    var labels = {
      idle: "ready",
      thinking: "thinking",
      working: "working",
      waiting: "waiting",
      done: "completed",
      error: "error",
      offline: "offline"
    };
    return labels[state] || "ready";
  }

  function escapeHtml(text) {
    return String(text).replace(/[&<>"']/g, function (ch) {
      return {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
      }[ch];
    });
  }

  function escapeAttr(text) {
    return String(text).replace(/[&<>"']/g, function (ch) {
      return {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
      }[ch];
    });
  }

  function clamp(value, min, max) {
    value = Number(value);
    if (isNaN(value)) {
      value = 0;
    }
    if (value < min) {
      return min;
    }
    if (value > max) {
      return max;
    }
    return value;
  }

  function parseDate(value) {
    if (!value) {
      return null;
    }
    var time = Date.parse(value);
    if (isNaN(time)) {
      return null;
    }
    return new Date(time);
  }

  function shortTime(value) {
    var date = parseDate(value) || new Date();
    return pad(date.getHours()) + ":" + pad(date.getMinutes()) + ":" + pad(date.getSeconds());
  }

  function poll() {
    var now = new Date().getTime();
    if (authRequired && !authUnlocked) {
      return;
    }

    if (pollInFlight && now - pollInFlightAt < 10000) {
      return;
    }
    pollInFlight = true;
    pollInFlightAt = now;

    xhr("GET", "/api/tasks?ts=" + new Date().getTime(), null, function (err, board) {
      pollInFlight = false;
      if (err) {
        if (err.status === 401 || err.authRequired || (err.payload && err.payload.authRequired)) {
          showAuthGate("Enter the phone password shown on your Mac.");
          return;
        }
        if (new Date().getTime() - lastSeenAt > 5000) {
          document.body.className = "state-offline";
          $("stateText").innerHTML = "OFFLINE";
          $("signal").className = "offline";
          currentState = "offline";
        }
        return;
      }

      applyBoard(board);
    });
  }

  function tick() {
    var now = new Date();
    $("clock").innerHTML = pad(now.getHours()) + ":" + pad(now.getMinutes()) + ":" + pad(now.getSeconds());
  }

  function pad(value) {
    return value < 10 ? "0" + value : String(value);
  }

  updateViewportLayout();
  if (window.addEventListener) {
    window.addEventListener("resize", updateViewportLayout, false);
    window.addEventListener("orientationchange", function () {
      typingViewportWidth = 0;
      typingViewportHeight = 0;
      setTimeout(updateViewportLayout, 300);
    }, false);
    if (window.visualViewport && window.visualViewport.addEventListener) {
      window.visualViewport.addEventListener("resize", updateViewportLayout, false);
    }
  }

    $("taskList").onclick = clickTask;
    $("closeTask").onclick = closeTaskPanel;
    $("sendInstruction").onclick = sendInstruction;
    $("copyMessages").onclick = copyPanelMessages;
    $("authUnlock").onclick = function () {
      unlockWithPin($("authPin").value, false);
    };
  $("authPin").onkeydown = function (event) {
    event = event || window.event;
    if (event.key === "Enter" || event.keyCode === 13) {
      unlockWithPin($("authPin").value, false);
      return false;
    }
    return true;
  };
  prepareInstructionInput($("instructionInput"));
  bindInstructionInput($("instructionInput"));

  setTimeout(updateViewportLayout, 300);
  initAuth();
  setInterval(poll, 1000);
  setInterval(tick, 1000);
}());
