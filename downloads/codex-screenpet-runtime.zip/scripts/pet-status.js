"use strict";

var fs = require("fs");
var path = require("path");

var ROOT = path.resolve(__dirname, "..");
var DATA_DIR = path.join(ROOT, "data");
var STATUS_FILE = path.join(DATA_DIR, "status.json");
var TASKS_FILE = path.join(DATA_DIR, "tasks.json");
var allowedStates = {
  idle: true,
  thinking: true,
  working: true,
  waiting: true,
  done: true,
  error: true,
  offline: true
};

function usage() {
  console.log("Usage:");
  console.log("  npm run pet -- <state> [message] [progress] [detail] [task]");
  console.log("");
  console.log("Example:");
  console.log("  npm run pet -- working \"Editing files\" 45 \"Building Blinky Codex ScreenPet\" \"Blinky setup\"");
}

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function readPrevious() {
  try {
    return JSON.parse(fs.readFileSync(STATUS_FILE, "utf8"));
  } catch (err) {
    return {
      state: "idle",
      title: "Blinky Codex ScreenPet",
      task: "Waiting for task",
      message: "Ready",
      detail: "Blinky watches your Codex tasks blink by blink.",
      progress: 0,
      updatedAt: new Date().toISOString(),
      startedAt: new Date().toISOString()
    };
  }
}

function readTasks() {
  try {
    var parsed = JSON.parse(fs.readFileSync(TASKS_FILE, "utf8"));
    if (Array.isArray(parsed)) {
      return parsed;
    }
    if (Array.isArray(parsed.tasks)) {
      return parsed.tasks;
    }
  } catch (err) {
  }
  return [];
}

function sortTasks(tasks) {
  return tasks.slice(0).sort(function (a, b) {
    var ap = priority(a.state);
    var bp = priority(b.state);
    var at;
    var bt;

    if (ap !== bp) {
      return ap - bp;
    }

    at = Date.parse(a.updatedAt || "") || 0;
    bt = Date.parse(b.updatedAt || "") || 0;
    return bt - at;
  });
}

function priority(state) {
  var values = {
    error: 0,
    waiting: 1,
    working: 2,
    thinking: 3,
    done: 8,
    idle: 9,
    offline: 10
  };
  return typeof values[state] === "number" ? values[state] : 9;
}

function syncCurrentTask(status) {
  var tasks = readTasks();
  var task = {
    id: "current",
    state: status.state,
    title: status.task || status.title || "Current Codex task",
    message: status.message,
    detail: status.detail,
    progress: status.progress,
    updatedAt: status.updatedAt,
    startedAt: status.startedAt
  };
  var found = false;
  var i;

  for (i = 0; i < tasks.length; i += 1) {
    if (tasks[i].id === task.id) {
      tasks[i] = task;
      found = true;
      break;
    }
  }

  if (!found) {
    tasks.push(task);
  }

  fs.writeFileSync(TASKS_FILE, JSON.stringify(sortTasks(tasks).slice(0, 30), null, 2));
}

function cleanText(value, fallback, limit) {
  var text = typeof value === "undefined" || value === null || value === "" ? fallback : String(value);
  text = text.replace(/[\r\n\t]+/g, " ").replace(/\s\s+/g, " ").trim();
  if (text.length > limit) {
    text = text.slice(0, limit - 1) + "...";
  }
  return text;
}

function progress(value, fallback, state) {
  if (typeof value === "undefined" || value === "") {
    if (state === "done") {
      return 100;
    }
    if (state === "idle") {
      return 0;
    }
    return fallback || 0;
  }

  var n = Number(value);
  if (!isFinite(n)) {
    n = fallback || 0;
  }
  if (n < 0) {
    return 0;
  }
  if (n > 100) {
    return 100;
  }
  return Math.round(n);
}

var args = process.argv.slice(2);
var state = String(args[0] || "").toLowerCase();

if (!state || !allowedStates[state]) {
  usage();
  process.exit(state ? 1 : 0);
}

ensureDataDir();

var previous = readPrevious();
var now = new Date().toISOString();
var next = {
  state: state,
  title: "Codex",
  task: cleanText(args[4], previous.task || "Current Codex task", 64),
  message: cleanText(args[1], previous.message || "Ready", 72),
  detail: cleanText(args[3], previous.detail || "", 120),
  progress: progress(args[2], previous.progress, state),
  updatedAt: now,
  startedAt: state === previous.state ? previous.startedAt || now : now
};

if (state === "idle") {
  next.title = "Blinky Codex ScreenPet";
  next.task = cleanText(args[4], "Waiting for task", 64);
}

fs.writeFileSync(STATUS_FILE, JSON.stringify(next, null, 2));
syncCurrentTask(next);
console.log(next.state + " " + next.progress + "% - " + next.message);
