"use strict";

var fs = require("fs");
var path = require("path");

var ROOT = path.resolve(__dirname, "..");
var DATA_DIR = path.join(ROOT, "data");
var INSTRUCTIONS_FILE = path.join(DATA_DIR, "instructions.json");

function readInstructions() {
  try {
    var parsed = JSON.parse(fs.readFileSync(INSTRUCTIONS_FILE, "utf8"));
    if (Array.isArray(parsed)) {
      return parsed;
    }
    if (Array.isArray(parsed.instructions)) {
      return parsed.instructions;
    }
  } catch (err) {
  }
  return [];
}

function format(item) {
  return [
    "[" + (item.status || "queued") + "]",
    item.taskId || "current",
    item.createdAt || "",
    "-",
    item.text || ""
  ].join(" ");
}

var status = String(process.argv[2] || "queued").toLowerCase();
var instructions = readInstructions();
var shown = 0;
var i;

for (i = 0; i < instructions.length; i += 1) {
  if (status === "all" || instructions[i].status === status) {
    console.log(format(instructions[i]));
    shown += 1;
  }
}

if (!shown) {
  console.log("No " + status + " instructions.");
}
