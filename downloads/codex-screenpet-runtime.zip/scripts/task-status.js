"use strict";

var fs = require("fs");
var path = require("path");

var ROOT = path.resolve(__dirname, "..");
var DATA_DIR = path.join(ROOT, "data");
var TASKS_FILE = path.join(DATA_DIR, "tasks.json");
var STATUS_FILE = path.join(DATA_DIR, "status.json");
var allowedStates = {
  idle: true,
  thinking: true,
  working: true,
  waiting: true,
  done: true,
  error: true,
  offline: true
};

function usage() {
  console.log("Usage:");
  console.log("  npm run task -- <id> <state> <title> [progress] [message] [detail]");
  console.log("");
  console.log("Example:");
  console.log("  npm run task -- pet-ui working \"Multi-task pet UI\" 60 \"Updating task list\"");
}

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function cleanText(value, fallback, limit) {
  var text = typeof value === "undefined" || value === null || value === "" ? fallback : String(value);
  text = text.replace(/[\r\n\t]+/g, " ").replace(/\s\s+/g, " ").trim();
  if (text.length > limit) {
    text = text.slice(0, limit - 1) + "...";
  }
  return text;
}

function cleanId(value) {
  var text = String(value || "current").toLowerCase();
  text = text.replace(/[^a-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "");
  return text || "current";
}

function progress(value, fallback, state) {
  var n;
  if (typeof value === "undefined" || value === "") {
    if (state === "done") {
      return 100;
    }
    if (state === "idle") {
      return 0;
    }
    return fallback || 0;
  }

  n = Number(value);
  if (!isFinite(n)) {
    n = fallback || 0;
  }
  if (n < 0) {
    return 0;
  }
  if (n > 100) {
    return 100;
  }
  return Math.round(n);
}

function readTasks() {
  try {
    var raw = fs.readFileSync(TASKS_FILE, "utf8");
    var parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed;
    }
    if (Array.isArray(parsed.tasks)) {
      return parsed.tasks;
    }
  } catch (err) {
  }
  return [];
}

function sortTasks(tasks) {
  return tasks.slice(0).sort(function (a, b) {
    var ap = priority(a.state);
    var bp = priority(b.state);
    var at;
    var bt;
    if (ap !== bp) {
      return ap - bp;
    }
    at = Date.parse(a.updatedAt || "") || 0;
    bt = Date.parse(b.updatedAt || "") || 0;
    return bt - at;
  });
}

function priority(state) {
  var values = {
    error: 0,
    waiting: 1,
    working: 2,
    thinking: 3,
    done: 8,
    idle: 9,
    offline: 10
  };
  return typeof values[state] === "number" ? values[state] : 9;
}

function activeTasks(tasks) {
  var out = [];
  var i;
  for (i = 0; i < tasks.length; i += 1) {
    if (tasks[i].state !== "done" && tasks[i].state !== "idle" && tasks[i].state !== "offline") {
      out.push(tasks[i]);
    }
  }
  return out;
}

function statusFromTasks(tasks) {
  var sorted = sortTasks(tasks);
  var active = activeTasks(sorted);
  var source = active[0] || sorted[0];
  var average = 0;
  var i;

  if (!source) {
    return {
      state: "idle",
      title: "Blinky Codex ScreenPet",
      task: "Waiting for task",
      message: "Ready",
      detail: "Blinky watches your Codex tasks blink by blink.",
      progress: 0,
      updatedAt: new Date().toISOString(),
      startedAt: new Date().toISOString()
    };
  }

  if (active.length) {
    for (i = 0; i < active.length; i += 1) {
      average += Number(active[i].progress) || 0;
    }
    average = Math.round(average / active.length);
  } else {
    average = source.progress;
  }

  return {
    state: source.state,
    title: active.length ? active.length + " running" : "Blinky Codex ScreenPet",
    task: source.title,
    message: source.message || (active.length ? "Tasks are running" : "No active task"),
    detail: active.length ? active.length + " active task" + (active.length === 1 ? "" : "s") : source.detail,
    progress: average,
    updatedAt: source.updatedAt,
    startedAt: source.startedAt
  };
}

var args = process.argv.slice(2);
var id = cleanId(args[0]);
var state = String(args[1] || "").toLowerCase();
var title = args[2];

if (!args[0] || !state || !allowedStates[state] || !title) {
  usage();
  process.exit(args.length ? 1 : 0);
}

ensureDataDir();

var tasks = readTasks();
var index = -1;
var previous = { id: id };
var i;
var now = new Date().toISOString();
var next;

for (i = 0; i < tasks.length; i += 1) {
  if (tasks[i].id === id) {
    index = i;
    previous = tasks[i];
    break;
  }
}

next = {
  id: id,
  state: state,
  title: cleanText(title, previous.title || "Untitled task", 64),
  progress: progress(args[3], previous.progress, state),
  message: cleanText(args[4], previous.message || "", 72),
  detail: cleanText(args[5], previous.detail || "", 120),
  updatedAt: now,
  startedAt: state === previous.state ? previous.startedAt || now : now
};

if (index >= 0) {
  tasks[index] = next;
} else {
  tasks.push(next);
}

tasks = sortTasks(tasks).slice(0, 30);
fs.writeFileSync(TASKS_FILE, JSON.stringify(tasks, null, 2));
fs.writeFileSync(STATUS_FILE, JSON.stringify(statusFromTasks(tasks), null, 2));
console.log(next.id + " " + next.state + " " + next.progress + "% - " + next.title);
