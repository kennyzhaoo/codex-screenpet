# Examples

This folder is for future demo configs and public-safe sample data.

Good examples to add later:

- fake task board JSON
- demo mode screenshots
- launchd plist example for macOS auto-start
- sample reverse proxy config with authentication

Do not put private Codex logs or real conversation exports here.
